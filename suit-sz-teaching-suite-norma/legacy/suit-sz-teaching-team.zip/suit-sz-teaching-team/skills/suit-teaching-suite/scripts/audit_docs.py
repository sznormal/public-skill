#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""教学文件审核（只读）。

面向「教学文件已经写好、要送教研室/教务检查」的场景，对成组文件做三类机器可判定的审核：

1. 教学必备项目 —— 章节、头部字段、必备表格是否在位并填实
2. 表格填写完整度 —— 空单元格、模板占位符与说明文字残留
3. 跨文件一致性 —— 课程名/类别/专业/教师/学期是否一致，学时勾稽、周次连续性、思政点覆盖率

只读：不修改任何输入文件。不使用子进程，不联网。

用法：
    <python> scripts/audit_docs.py 课程标准.docx 教案1.docx 课程计划.docx
    <python> scripts/audit_docs.py --dir ./教学文件 --out 审核报告.md --json 审核报告.json
    <python> scripts/audit_docs.py --demo-dir ./_audit_samples

结论级别：PASS 通过 / WARN 建议修改 / FAIL 必须修改 / UNVERIFIED 未能自动判定（转人工）。
存在 FAIL 时进程退出码为 1，便于团长与督导据此判定是否放行。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

PASS, WARN, FAIL, UNVERIFIED = "PASS", "WARN", "FAIL", "UNVERIFIED"
LEVEL_ORDER = {FAIL: 3, WARN: 2, UNVERIFIED: 1, PASS: 0}

G_ITEM, G_TABLE, G_CROSS = "教学必备项目", "表格填写完整度", "跨文件一致性"


# --------------------------------------------------------------------------
# 数据模型
# --------------------------------------------------------------------------
@dataclass
class Finding:
    gid: str          # 检查组
    idx: str          # 编号
    doc: str          # 文件名
    item: str         # 检查项
    expect: str       # 期望
    actual: str       # 实测
    where: str = ""   # 位置
    level: str = PASS
    note: str = ""


class DocInfo:
    """一份文档的扁平视图。"""

    def __init__(self, path: Path, doc):
        self.path = path
        self.name = path.name
        self.doc = doc
        self.paras = [p.text for p in doc.paragraphs if p.text.strip()]
        self.tables = list(doc.tables)
        self.table_texts: list[list[str]] = []
        for tb in self.tables:
            rows = []
            for r in tb.rows:
                rows.append([c.text for c in dedup_cells(r.cells)])
            self.table_texts.append(rows)
        self.cell_texts = [t for rows in self.table_texts for row in rows for t in row]
        self.all_texts = self.paras + self.cell_texts
        self.flat = "\n".join(self.all_texts)
        self.kind, self.kind_reason = detect_kind(self)


# --------------------------------------------------------------------------
# 基础工具
# --------------------------------------------------------------------------
_WS = re.compile(r"[\s\u3000\u00a0]+")


def norm(s: str) -> str:
    """压缩空白（含全角空格），便于正则匹配。"""
    return _WS.sub(" ", (s or "").replace("\u3000", " ")).strip()


def dedup_cells(cells) -> list:
    """合并单元格在 python-docx 中会重复返回同一 tc，按底层元素去重。"""
    out, seen = [], set()
    for c in cells:
        key = id(c._tc)
        if key in seen:
            continue
        seen.add(key)
        out.append(c)
    return out


def nonempty(cells) -> list[str]:
    return [norm(c.text) for c in dedup_cells(cells) if norm(c.text)]


def numbers(text: str) -> list[float]:
    return [float(x) for x in re.findall(r"\d+(?:\.\d+)?", text or "")]


def hours_in(text: str, lo: float = 1, hi: float = 500) -> list[int]:
    """抽学时量级的整数（排除年份等噪声）。"""
    return [int(n) for n in numbers(text) if n == int(n) and lo <= n <= hi]


def head_key(tb) -> str:
    """表头文本，去掉所有空白——模板常用「周　次」「教 学 内 容」这类字间距排版。"""
    if not tb.rows:
        return ""
    return "".join(norm(c.text) for c in dedup_cells(tb.rows[0].cells)).replace(" ", "")


def find_table(di: DocInfo, *keys: str):
    """按表头关键词找表（忽略空白），返回 (索引, table)。"""
    for ti, tb in enumerate(di.tables):
        if not tb.rows:
            continue
        head = head_key(tb)
        if all(k.replace(" ", "") in head for k in keys):
            return ti, tb
    return None, None


def field_value(texts: list[str], label: str):
    """宽松定位 label 的值。返回 (是否找到标签, 值, 位置)。"""
    lab = norm(label)
    for i, t in enumerate(texts):
        nt = norm(t)
        m = re.match(rf"^{re.escape(lab)}\s*[：:]\s*(.*)$", nt)
        if m:
            return True, m.group(1).strip(), f"第{i + 1}处"
        if nt == lab:
            for j in range(i + 1, min(i + 3, len(texts))):
                v = norm(texts[j])
                if v:
                    return True, v, f"第{i + 1}处下一段"
            return True, "", f"第{i + 1}处（标签后无内容）"
    return False, None, ""


PLACEHOLDERS = [
    (r"X{3,}", "XXX 占位符"),
    (r"[×xX]{4,}", "××× 占位符"),
    (r"\*{3,}", "*** 占位符"),
    (r"待定|待填|待补|待完善|待补充|TBD", "待填标记"),
    (r"（略）|\(\s*略\s*\)", "（略）占位"),
    (r"（?填入?|请填写|此处填", "填写提示残留"),
    (r"（?专业与学制）?|（一般分为|（含课程思政|（需包括|（说明开设|（选择适用|（采用的教学|（线上教学平台|（简要说明|（针对课程|（以实践项目|（专业与学制）", "模板说明文字残留"),
    (r"20\s+年|年\s+月\s+日|\d\s+月\s+\d\s+日", "日期槽未填实"),
]

SECTION_KEYWORDS = [
    "课程定位", "课程目标", "课程内容与要求", "实践教学",
    "课程实施", "教学评价", "线上教学资源", "其他说明",
]

CS_FIELDS = ["课程类别", "适用专业", "授课单位", "学分", "学时",
             "编写执笔人及编写日期", "审定负责人及审定日期"]

LESSON_FIELDS = ["课程名称", "课程类别", "任课班级", "任课教师", "所属院部"]

LESSON_TABLE_LABELS = ["教学单元", "周次", "时数", "授课班级", "教学目的及要求",
                       "教学重点", "教学难点", "实验仪器及教具", "课后作业"]

SCHEDULE_FIELDS = ["课程名称", "课程类别", "适用专业", "任课教师",
                   "教研室主任签名", "教研室通过日期"]

POLITICS_TITLE_RE = re.compile(r"课程思政|思政融入")


# --------------------------------------------------------------------------
# 文档类型识别
# --------------------------------------------------------------------------
def detect_kind(di: DocInfo) -> tuple[str, str]:
    n = di.name
    flat = di.flat
    # 周次表特征最独特，优先判授课计划（课标里也会出现"课程标准名称"字样）
    if "学期授课计划" in n or "课程计划" in n or "授课计划" in flat or "授课章节及内容提要" in flat:
        return "schedule", "文件名或内容含授课计划特征"
    if "教案" in n or ("教 学 过 程" in flat.replace("　", " ") and "教学单元" in flat):
        return "lesson", "文件名或内容含教案特征"
    if "课程标准" in n or ("课程标准" in flat and any(k in flat for k in ("课程内容与要求", "学时分配", "课程定位"))):
        return "course-standard", "文件名或内容含课程标准特征"
    return "unknown", "无法识别文档类型"


KIND_CN = {"course-standard": "课程标准", "lesson": "教案", "schedule": "授课计划", "unknown": "未知类型"}


# --------------------------------------------------------------------------
# 检查一：教学必备项目
# --------------------------------------------------------------------------
def check_required(di: DocInfo, ctr: list) -> list[Finding]:
    out = []
    k = di.kind
    if k == "unknown":
        out.append(Finding(G_ITEM, nid(ctr), di.name, "文档类型识别", "可识别为课程标准/教案/授课计划之一",
                           "未能识别", level=FAIL, note="请在文件名或标题中写明文档类型"))
        return out

    if k == "course-standard":
        # 章节齐备
        for kw in SECTION_KEYWORDS:
            hit = kw in di.flat
            out.append(Finding(G_ITEM, nid(ctr), di.name, f"章节「{kw}」", "存在该章节",
                               "存在" if hit else "缺失", level=PASS if hit else FAIL))
        # 头部字段
        for lab in CS_FIELDS:
            found, val, where = field_value(di.all_texts, lab)
            if not found:
                lv, act = WARN, "未找到该字段标签"
            elif not val:
                lv, act = FAIL, "标签后为空"
            elif placeholder_hit(val):
                lv, act = FAIL, f"仍是占位/说明文字：{val[:36]}"
            else:
                lv, act = PASS, val[:36]
            out.append(Finding(G_ITEM, nid(ctr), di.name, f"头部字段「{lab}」", "已填实",
                               act, where=where, level=lv))
        # 必备表
        out.extend(_check_cs_tables(di, ctr))
    elif k == "lesson":
        for lab in LESSON_FIELDS:
            found, val, where = field_value(di.all_texts, lab)
            if not found:
                lv, act = WARN, "未找到该字段标签"
            elif not val or placeholder_hit(val):
                lv, act = FAIL, ("标签后为空" if not val else f"仍是占位文字：{val[:36]}")
            else:
                lv, act = PASS, val[:36]
            out.append(Finding(G_ITEM, nid(ctr), di.name, f"教案头部「{lab}」", "已填实", act, where=where, level=lv))
        for lab in LESSON_TABLE_LABELS:
            hit = lab in di.flat
            out.append(Finding(G_ITEM, nid(ctr), di.name, f"教案栏目「{lab}」", "存在该栏目",
                               "存在" if hit else "缺失", level=PASS if hit else WARN))
        # 教学过程必须有内容
        out.append(_check_lesson_process(di, ctr))
        # 思政落点
        out.append(_check_lesson_politics(di, ctr))
    elif k == "schedule":
        for lab in SCHEDULE_FIELDS:
            found, val, where = field_value(di.all_texts, lab)
            if not found:
                lv, act = WARN, "未找到该字段标签"
            elif not val or placeholder_hit(val):
                lv, act = FAIL, ("标签后为空" if not val else f"仍是占位文字：{val[:36]}")
            else:
                lv, act = PASS, val[:36]
            out.append(Finding(G_ITEM, nid(ctr), di.name, f"授课计划头部「{lab}」", "已填实", act, where=where, level=lv))
        out.extend(_check_schedule_blocks(di, ctr))
    return out


def _check_cs_tables(di: DocInfo, ctr: list) -> list[Finding]:
    out = []
    # 学时分配表
    ti, tb = find_table(di, "学时")
    if tb is None:
        out.append(Finding(G_ITEM, nid(ctr), di.name, "学时分配表", "存在且含学时明细",
                           "未找到含「学时」表头的表", level=FAIL))
    else:
        rows_filled = sum(1 for r in tb.rows[1:] if len(nonempty(r.cells)) >= 2)
        lv = PASS if rows_filled else FAIL
        out.append(Finding(G_ITEM, nid(ctr), di.name, "学时分配表", "含已填的数据行",
                           f"已填 {rows_filled} 行", where=f"表{ti + 1}", level=lv))
    # 实践教学安排表（用「实践项目」而非「实践」：学时分配表表头也含「实践」列，会撞车）
    ti2, tb2 = find_table(di, "实践项目")
    if tb2 is None:
        out.append(Finding(G_ITEM, nid(ctr), di.name, "实践教学安排表", "存在", "未找到", level=WARN))
    else:
        rows_filled = sum(1 for r in tb2.rows[1:] if len(nonempty(r.cells)) >= 2)
        out.append(Finding(G_ITEM, nid(ctr), di.name, "实践教学安排表", "含已填的数据行",
                           f"已填 {rows_filled} 行", where=f"表{ti2 + 1}",
                           level=PASS if rows_filled else FAIL))
    # 课程思政融入表
    pti, ptb = find_table(di, "思政")
    if ptb is None:
        out.append(Finding(G_ITEM, nid(ctr), di.name, "课程思政融入表",
                           "存在且含 知识点/思政融入点/思政案例 三列",
                           "未找到含「思政」表头的表", level=FAIL,
                           note="课标模板本身不含此表，需按规范补充"))
    else:
        head = head_key(ptb)
        cols = [c for c in ("知识点", "思政融入点", "案例") if c in head]
        filled = [i for i, r in enumerate(ptb.rows[1:], start=1) if len(nonempty(r.cells)) >= 2]
        if len(cols) < 2:
            out.append(Finding(G_ITEM, nid(ctr), di.name, "课程思政融入表表头",
                               "含知识点/思政融入点/思政案例列", f"实测表头：{head[:50]}",
                               where=f"表{pti + 1}", level=WARN))
        out.append(Finding(G_ITEM, nid(ctr), di.name, "课程思政融入表数据行",
                           "至少 1 行三列非空", f"已填 {len(filled)} 行",
                           where=f"表{pti + 1}", level=PASS if filled else FAIL))
    return out


def _check_lesson_process(di: DocInfo, ctr: list) -> list[Finding]:
    for ti, tb in enumerate(di.tables):
        head = " ".join(norm(c.text) for c in dedup_cells(tb.rows[0].cells)).replace(" ", "")
        if "教学过程" in head:
            body = []
            for r in tb.rows[1:]:
                cells = nonempty(r.cells)
                if cells and not any(k in cells[0] for k in ("课后作业", "备注")):
                    body.append(cells[0])
            chars = sum(len(x) for x in body)
            lv = PASS if chars >= 80 else (WARN if chars else FAIL)
            return Finding(G_ITEM, nid(ctr), di.name, "教学过程正文", "有实质内容（≥80 字）",
                           f"{chars} 字", where=f"表{ti + 1}", level=lv)
    return Finding(G_ITEM, nid(ctr), di.name, "教学过程正文", "存在教学过程表",
                   "未找到含「教学过程」表头的表", level=WARN)


def _check_lesson_politics(di: DocInfo, ctr: list) -> list[Finding]:
    texts = [t for t in di.all_texts if POLITICS_TITLE_RE.search(t)]
    body = di.flat.replace(" ", "")
    if not texts:
        return Finding(G_ITEM, nid(ctr), di.name, "教案思政落点", "出现思政融入点或思政案例",
                       "全文未见思政相关表述", level=WARN,
                       note="素质目标或教学过程中应体现课标思政点")
    sample = texts[0][:40]
    return Finding(G_ITEM, nid(ctr), di.name, "教案思政落点", "出现思政融入点或思政案例",
                   f"命中 {len(texts)} 处，例：{sample}", level=PASS)


def _check_schedule_blocks(di: DocInfo, ctr: list) -> list[Finding]:
    out = []
    # 学时统计块
    stat_keys = ["教学周数", "周学时", "计划教学时数"]
    hit = [k for k in stat_keys if k in di.flat]
    out.append(Finding(G_ITEM, nid(ctr), di.name, "学时统计块",
                       "含教学周数/周学时/计划教学时数项",
                       f"命中 {len(hit)}/{len(stat_keys)}：{'、'.join(hit) or '无'}",
                       level=PASS if len(hit) == len(stat_keys) else FAIL))
    # 周次表
    ti, tb = find_table(di, "周次")
    if tb is None:
        out.append(Finding(G_ITEM, nid(ctr), di.name, "周次安排表", "存在", "未找到含「周次」表头的表", level=FAIL))
    else:
        seq = week_sequence(tb)
        if not seq:
            out.append(Finding(G_ITEM, nid(ctr), di.name, "周次安排表", "已填周次",
                               "周次列为空", where=f"表{ti + 1}", level=FAIL))
        else:
            expect = list(range(1, len(seq) + 1))
            ok = seq == expect
            out.append(Finding(G_ITEM, nid(ctr), di.name, "周次连续性", "1~N 连续无断档",
                               f"实测 {seq[0]}~{seq[-1]}，共 {len(seq)} 周" + ("" if ok else "（有断档或重复）"),
                               where=f"表{ti + 1}", level=PASS if ok else FAIL))
    return out


def week_sequence(tb) -> list[int]:
    seq = []
    for r in tb.rows[1:]:
        cells = nonempty(r.cells)
        if not cells:
            continue
        n = re.findall(r"\d+", cells[0])
        if n:
            seq.append(int(n[0]))
    return seq


# --------------------------------------------------------------------------
# 检查二：表格填写完整度
# --------------------------------------------------------------------------
def check_tables(di: DocInfo, ctr: list) -> list[Finding]:
    out = []
    key_table_ids = _key_tables(di)
    for ti, tb in enumerate(di.tables):
        rows = tb.rows
        if len(rows) < 2:
            continue
        head = " ".join(norm(c.text) for c in dedup_cells(rows[0].cells))
        blank, total, samples = _blank_stats(tb)
        if total == 0:
            continue
        rate = blank / total
        is_key = ti in key_table_ids
        if is_key and rate > 0.95:
            lv = FAIL
        elif rate >= 0.6:
            lv = FAIL if is_key else WARN
        elif rate > 0.3:
            lv = WARN
        else:
            lv = PASS
        out.append(Finding(G_TABLE, nid(ctr), di.name, f"表{ti + 1} 填写完整度",
                           "空格率 ≤30%（关键表需基本填满）",
                           f"空格 {blank}/{total}（{rate:.0%}）",
                           where=f"表{ti + 1}：{head[:32]}", level=lv,
                           note=("　空值位置示例：" + "、".join(samples[:6])) if (lv != PASS and samples) else ""))
        # 占位符残留
        ph = placeholder_scan(tb)
        if ph:
            out.append(Finding(G_TABLE, nid(ctr), di.name, f"表{ti + 1} 占位符残留",
                               "无模板占位/说明文字",
                               f"命中 {len(ph)} 处：" + "、".join(f"{w}({d})" for w, d in ph[:5]),
                               where=f"表{ti + 1}", level=WARN))
    # 段落级占位符
    ph = placeholder_scan_texts(di.paras)
    if ph:
        out.append(Finding(G_TABLE, nid(ctr), di.name, "正文占位符残留", "无模板占位/说明文字",
                           f"命中 {len(ph)} 处：" + "、".join(f"{w}({d})" for w, d in ph[:5]),
                           level=WARN))
    return out


def _key_tables(di: DocInfo) -> set[int]:
    keys = set()
    for ti, tb in enumerate(di.tables):
        head = head_key(tb)
        if any(k in head for k in ("思政", "学时", "周次", "教学过程", "实践")):
            keys.add(ti)
    return keys


EXEMPT_HEADERS = ("备注", "说明", "其他")


def _blank_stats(tb):
    """统计数据区空格（跳过表头行，豁免备注/说明等选填列，合并单元格只计一次）。"""
    exempt = set()
    if tb.rows:
        for ci, c in enumerate(tb.rows[0].cells):
            if any(k in norm(c.text).replace(" ", "") for k in EXEMPT_HEADERS):
                exempt.add(ci)
    blank = total = 0
    samples = []
    seen: set[int] = set()
    for ri, r in enumerate(tb.rows[1:], start=1):
        for ci, c in enumerate(r.cells):
            key = id(c._tc)
            if key in seen:
                continue
            seen.add(key)
            if ci in exempt:
                continue
            total += 1
            if not norm(c.text):
                blank += 1
                samples.append(f"r{ri + 1}c{ci + 1}")
    return blank, total, samples


def placeholder_hit(text: str) -> str | None:
    t = norm(text)
    for pat, desc in PLACEHOLDERS:
        if re.search(pat, t):
            return desc
    return None


def placeholder_scan(tb) -> list[tuple[str, str]]:
    hits = []
    for r in tb.rows:
        for c in dedup_cells(r.cells):
            t = norm(c.text)
            if not t:
                continue
            d = placeholder_hit(t)
            if d:
                hits.append((t[:24], d))
    return hits


def placeholder_scan_texts(texts: list[str]) -> list[tuple[str, str]]:
    hits = []
    for t in texts:
        n = norm(t)
        if not n:
            continue
        d = placeholder_hit(n)
        if d:
            hits.append((n[:24], d))
    return hits


# --------------------------------------------------------------------------
# 检查三：跨文件一致性
# --------------------------------------------------------------------------
def check_cross(docs: dict[str, DocInfo], ctr: list) -> list[Finding]:
    out = []
    cs, lessons, sched = docs.get("course-standard"), docs.get("lesson", []), docs.get("schedule")

    # 缺失文件的处理口径
    missing = []
    if cs is None:
        missing.append("课程标准")
    if not lessons:
        missing.append("教案")
    if sched is None:
        missing.append("授课计划")
    if missing:
        lv = WARN if len(missing) < 3 else FAIL
        out.append(Finding(G_CROSS, nid(ctr), "（整体）", "三类文件齐备",
                           "课标 + 教案 + 授课计划",
                           "缺失：" + "、".join(missing) + "；涉及缺对照文件的检查标为未验证",
                           level=lv))
    if len(missing) == 3:
        return out

    # 3.1 课程名称
    cs_name = extract_cs_name(cs) if cs else None
    names = {"课程标准": cs_name}
    if lessons:
        names["教案"] = field_value(lessons[0].all_texts, "课程名称")[1]
    if sched:
        names["授课计划"] = field_value(sched.all_texts, "课程名称")[1]
    out.append(_consistency(G_CROSS, ctr, "课程名称", names))

    # 3.1b 学年学期一致性
    sem = {}
    for nm, di in [("课程标准", cs), ("授课计划", sched)] + \
                  [(f"教案{i + 1}", l) for i, l in enumerate(lessons)]:
        if di:
            t = semester_tag(di)
            if t:
                sem[nm] = t
    out.append(_consistency(G_CROSS, ctr, "学年学期", sem))

    # 3.1c 日期逻辑：审定日期不应早于编写日期
    if cs:
        d1 = parse_date(field_value(cs.all_texts, "编写执笔人及编写日期")[1] or "")
        d2 = parse_date(field_value(cs.all_texts, "审定负责人及审定日期")[1] or "")
        if d1 and d2:
            ok = d1 <= d2
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "日期逻辑（编写 ≤ 审定）",
                               "审定日期不早于编写日期",
                               f"编写 {d1[0]}-{d1[1]:02d}-{d1[2]:02d}，审定 {d2[0]}-{d2[1]:02d}-{d2[2]:02d}",
                               level=PASS if ok else FAIL,
                               note="" if ok else "审定日期早于编写日期，逻辑不成立"))
        else:
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "日期逻辑（编写 ≤ 审定）",
                               "两个日期均可读且审定不早于编写",
                               f"编写日期={'可读' if d1 else '未读到'}，审定日期={'可读' if d2 else '未读到'}",
                               level=UNVERIFIED, note="请人工核对课标头部两个日期"))

    # 3.2 课程类别 / 适用专业 / 任课教师
    for label, key in (("课程类别", "课程类别"), ("适用专业", "适用专业")):
        vals = {}
        if cs:
            vals["课程标准"] = field_value(cs.all_texts, label)[1]
        if sched:
            vals["授课计划"] = field_value(sched.all_texts, label)[1]
        if lessons:
            vals["教案"] = field_value(lessons[0].all_texts, label)[1]
        out.append(_consistency(G_CROSS, ctr, label, vals))

    vals = {}
    if sched:
        vals["授课计划"] = field_value(sched.all_texts, "任课教师")[1]
    if lessons:
        vals["教案"] = field_value(lessons[0].all_texts, "任课教师")[1]
    out.append(_consistency(G_CROSS, ctr, "任课教师", vals))

    # 3.3 学时勾稽：优先按列定位（可靠），定位不到才退回数字集合（启发式，须标注）
    if cs and sched:
        cs_total, cs_where = cs_total_hours(cs)
        sch_total, sch_where = schedule_total_hours(sched)
        if cs_total is None:
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "总学时勾稽",
                               "课标学时总计可读", "未能从课标读出学时总计",
                               level=UNVERIFIED, note="请人工核对课标学时分配表「学时总计」行"))
        elif sch_total is not None:
            ok = cs_total == sch_total
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "总学时勾稽",
                               f"授课计划计划教学时数 = 课标学时总计（{cs_total}）",
                               f"课标 {cs_total}（{cs_where}）｜授课计划 {sch_total}（{sch_where}）",
                               where=f"{cs_where} ↔ {sch_where}",
                               level=PASS if ok else FAIL,
                               note="" if ok else "请核对课标「学时总计」与授课计划「本学期计划教学时数/总时数」"))
        else:
            pool = sorted({h for h in hours_in(sched.flat)})
            ok = cs_total in pool
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "总学时勾稽",
                               f"授课计划应出现课标总学时 {cs_total}",
                               ("数字集合命中，但未定位到具体列" if ok
                                else f"未命中；授课计划学时量级数字：{pool[:10]}"),
                               where=cs_where, level=PASS if ok else FAIL,
                               note="启发式：未能定位「计划教学时数」列，按数字集合判定，需人工确认对应关系"))
    # 3.4 学时分解（讲授/实践）
    if cs and sched:
        out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "学时分解（讲授/实践）",
                           "课标「其中」与授课计划「其中」口径一致",
                           "需人工核对课标学时分配表「讲授/实践」与授课计划「其中」各列",
                           level=UNVERIFIED, note="列结构差异大，不做自动判定"))

    # 3.5 思政点覆盖
    if cs:
        pts = politics_points(cs)
        if pts:
            lesson_text = "".join(l.flat.replace(" ", "") for l in lessons)
            if not lessons:
                out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "思政点覆盖",
                                   "课标思政点应在教案中体现", f"课标 {len(pts)} 个思政点，无教案可对照",
                                   level=UNVERIFIED, note="缺教案，标为未验证"))
            else:
                uncovered = [p for p in pts if p not in lesson_text]
                lv = PASS if not uncovered else (WARN if len(uncovered) < len(pts) else FAIL)
                out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "思政点覆盖",
                                   "课标每行思政融入点均有教案落点",
                                   f"覆盖 {len(pts) - len(uncovered)}/{len(pts)}"
                                   + (f"；未覆盖：{'、'.join(uncovered[:6])}" if uncovered else ""),
                                   where="课标 课程思政融入表", level=lv,
                                   note="启发式：按思政融入点关键词在教案全文匹配"))
        else:
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "思政点覆盖",
                               "课标含可提取的思政融入点", "课标未提供思政融入点（思政表缺或为空）",
                               level=UNVERIFIED, note="先补齐课标课程思政融入表"))

    # 3.6 模块/内容对齐
    if cs and sched:
        mods = cs_modules(cs)
        if mods:
            sch_text = sched.flat.replace(" ", "")
            miss = [m for m in mods if m.replace(" ", "") not in sch_text]
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "模块对齐（课标→授课计划）",
                               "课标各教学模块均出现在授课计划内容提要",
                               f"对齐 {len(mods) - len(miss)}/{len(mods)}"
                               + (f"；未出现：{'、'.join(miss[:5])}" if miss else ""),
                               level=PASS if not miss else WARN,
                               note="启发式：按模块名在授课计划全文匹配"))
        else:
            out.append(Finding(G_CROSS, nid(ctr), "（跨文件）", "模块对齐（课标→授课计划）",
                               "课标含可提取的模块/教学内容", "未能自动提取模块名",
                               level=UNVERIFIED, note="请人工核对课标章节与授课计划内容提要"))
    return out


def _core_value(v: str) -> str:
    """去掉括号补充说明与空格，用于宽松比对。"""
    return re.sub(r"[（(][^）)]*[）)]", "", v or "").replace(" ", "").strip()


def _consistency(gid: str, ctr: list, item: str, vals: dict[str, str | None]) -> Finding:
    present = {k: norm(v) for k, v in vals.items() if norm(v or "")}
    if len(present) < 2:
        return Finding(gid, nid(ctr), "（跨文件）", item,
                       "至少两份文件可读出该字段", f"仅读到 {len(present)} 份：{present}",
                       level=UNVERIFIED, note="未能自动定位，请人工核对")
    detail = "；".join(f"{k}={v[:28]}" for k, v in present.items())
    if len(set(present.values())) == 1:
        return Finding(gid, nid(ctr), "（跨文件）", item, "各文件取值一致",
                       f"一致：{list(present.values())[0][:40]}", level=PASS)
    if len({_core_value(v) for v in present.values()}) == 1:
        return Finding(gid, nid(ctr), "（跨文件）", item,
                       "各文件取值一致（允许括号补充说明差异）", detail, level=WARN,
                       note="实质相同，仅表述或补充说明不同，请确认是否为同一对象")
    return Finding(gid, nid(ctr), "（跨文件）", item, "各文件取值一致", detail,
                   level=FAIL, note="存在实质不一致，须统一为同一值")


SEM_RE = re.compile(r"20\d{2}\s*年?\s*[/／\-、]\s*20\d{2}\s*年?\s*第?\s*([0-9一二])\s*学期")
DATE_RE = re.compile(r"(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日")


def semester_tag(di: DocInfo) -> str | None:
    """抽取「2026年/2027年第1学期」这类学期标识。"""
    m = SEM_RE.search(di.flat.replace(" ", ""))
    return m.group(0) if m else None


def parse_date(text: str):
    m = DATE_RE.search(norm(text).replace(" ", ""))
    return tuple(int(x) for x in m.groups()) if m else None


def extract_cs_name(cs: DocInfo) -> str | None:
    for t in cs.all_texts:
        m = re.search(r"《([^》]{2,40})》\s*课程标准", norm(t))
        if m:
            return m.group(1)
    v = field_value(cs.all_texts, "课程名称")[1]
    return v or None


def cs_total_hours(cs: DocInfo) -> tuple[int | None, str]:
    for ti, tb in enumerate(cs.tables):
        for ri, r in enumerate(tb.rows):
            cells = nonempty(r.cells)
            if cells and "学时总计" in cells[0]:
                for c in cells[1:]:
                    h = hours_in(c)
                    if h:
                        return h[0], f"表{ti + 1} 第{ri + 1}行「学时总计」"
        # 兜底：整表最后一行
    found, val, where = field_value(cs.all_texts, "学时")
    if found and val:
        h = hours_in(val)
        if h:
            return h[0], f"头部「学时」（{where}）"
    return None, ""


def locate_column(tb, *keys: str):
    """在表头各列中定位关键词所在的真实列索引（用未去重的 cells 下标，保证列号真实）。

    返回 (表头行号, 列号)；找不到返回 (None, None)。
    """
    for ri, r in enumerate(tb.rows):
        for ci, c in enumerate(r.cells):
            if any(k in norm(c.text) for k in keys):
                return ri, ci
    return None, None


def schedule_total_hours(sched: DocInfo) -> tuple[int | None, str]:
    """从授课计划的学时统计表按列定位「计划教学时数/总时数」的值。

    按列取值比「整表数字集合」可靠得多：集合命中会把「讲授48/实验16」里的 48
    误当成总学时，导致课标 48 与授课计划 64 不一致时漏报。
    """
    for ti, tb in enumerate(sched.tables):
        hri, ci = locate_column(tb, "计划教学时数", "总 时 数", "总时数", "实际教学时数")
        if ci is None:
            continue
        for ri, r in enumerate(tb.rows[hri + 1:], start=hri + 1):
            cells = r.cells
            if ci < len(cells):
                h = hours_in(cells[ci].text)
                if h:
                    head_cells = tb.rows[hri].cells
                    key = norm(head_cells[ci].text) if ci < len(head_cells) else ""
                    return h[0], f"表{ti + 1} 第{ri + 1}行「{key or '学时统计'}」列"
    # 兜底：全文找「计划教学时数」附近的数字
    found, val, where = field_value(sched.all_texts, "计划教学时数")
    if found and val:
        h = hours_in(val)
        if h:
            return h[0], f"文本「计划教学时数」（{where}）"
    return None, ""


def politics_points(cs: DocInfo) -> list[str]:
    ti, tb = find_table(cs, "思政")
    if tb is None:
        return []
    rows = tb.rows
    if len(rows) < 2:
        return []
    head = [norm(c.text) for c in dedup_cells(rows[0].cells)]
    col = next((i for i, h in enumerate(head) if "融入点" in h or "思政点" in h), 1)
    pts = []
    for r in rows[1:]:
        cells = [norm(c.text) for c in dedup_cells(r.cells)]
        if len(cells) <= col:
            continue
        raw = cells[col]
        if not raw:
            continue
        for part in re.split(r"[、，,;；/／\s]+", raw):
            p = part.strip("。.（）()")
            if len(p) >= 2:
                pts.append(p)
    return list(dict.fromkeys(pts))


def cs_modules(cs: DocInfo) -> list[str]:
    """从课标教学内容表抽取模块名（序号行第 2 列）。"""
    _ti, tb = find_table(cs, "教学内容")
    if tb is None:
        return []
    mods = []
    for r in tb.rows[1:]:
        cells = nonempty(r.cells)
        if len(cells) >= 2 and re.match(r"^\d+$", cells[0]):
            name = re.sub(r"^[（(]?\d+[）)]?[、.．]?\s*", "", cells[1]).strip()
            if len(name) >= 2:
                mods.append(name)
    return mods


# --------------------------------------------------------------------------
# 编号与汇总
# --------------------------------------------------------------------------
def nid(ctr: list) -> str:
    ctr[0] += 1
    return f"{ctr[0]:02d}"


def summarize(findings: list[Finding]) -> dict:
    c = {PASS: 0, WARN: 0, FAIL: 0, UNVERIFIED: 0}
    for f in findings:
        c[f.level] += 1
    if c[FAIL]:
        verdict = "❌ 不通过"
    elif c[WARN]:
        verdict = "⚠️ 有瑕疵"
    else:
        verdict = "✅ 通过"
    return {"counts": c, "verdict": verdict, "total": len(findings)}


# --------------------------------------------------------------------------
# 报告
# --------------------------------------------------------------------------
def render_markdown(findings: list[Finding], docs_desc: list[str], kind_of: dict) -> str:
    s = summarize(findings)
    c = s["counts"]
    lines = [
        "# 教学文件审核报告",
        "",
        f"- 检查范围：{len(docs_desc)} 份文件",
        *[f"  - {d}" for d in docs_desc],
        f"- 结论：**{s['verdict']}**",
        f"- 统计：❌ 必须修改 {c[FAIL]} 项 ｜ ⚠️ 建议修改 {c[WARN]} 项 ｜ "
        f"未自动判定 {c[UNVERIFIED]} 项 ｜ ✅ 通过 {c[PASS]} 项（共 {s['total']} 项）",
        "",
        "> 本报告由 `scripts/audit_docs.py` 生成，全部结论基于文档结构与文本的机器判定。",
        "> 标注「启发式」的项为关键词/数字匹配，需督导人工确认对应关系；标注「未自动判定」的项请人工核对。",
        "",
    ]
    for gid in (G_ITEM, G_TABLE, G_CROSS):
        group = [f for f in findings if f.gid == gid]
        if not group:
            continue
        lines += [f"## {gid}", "", "| # | 文件 | 检查项 | 期望 | 实测 | 位置 | 结论 |", "|---|---|---|---|---|---|---|"]
        icon = {FAIL: "❌", WARN: "⚠️", PASS: "✅", UNVERIFIED: "❔"}
        for f in group:
            act = f.actual + (f"　—　{f.note}" if f.note else "")
            lines.append(
                f"| {f.idx} | {f.doc} | {f.item} | {f.expect} | {act} | {f.where or '—'} | {icon[f.level]} |"
            )
        lines.append("")
    # 问题清单
    must = [f for f in findings if f.level == FAIL]
    adv = [f for f in findings if f.level == WARN]
    manual = [f for f in findings if f.level == UNVERIFIED]
    lines += ["## 问题清单（按严重度）", ""]
    if must:
        lines += ["### ❌ 必须修改", ""]
        lines += [f"- **[{f.idx}] {f.doc} · {f.item}**：{f.actual}　（期望：{f.expect}；位置：{f.where or '—'}）" for f in must]
        lines.append("")
    if adv:
        lines += ["### ⚠️ 建议修改", ""]
        lines += [f"- [{f.idx}] {f.doc} · {f.item}：{f.actual}" for f in adv]
        lines.append("")
    if not must and not adv:
        lines += ["- 未发现必须修改或建议修改项。", ""]
    lines += ["### ❔ 需人工核对（脚本不做判定）", ""]
    if manual:
        lines += [f"- [{f.idx}] {f.doc} · {f.item}：{f.actual}" for f in manual]
    else:
        lines += ["- 无。"]
    lines.append("")
    # 整改建议
    lines += ["## 整改建议", ""]
    if must:
        lines.append("1. 先修 ❌ 项——这些是不合规项，不修无法通过检查。")
        lines.append("2. 再由主理人把 ❌ 项分派回对应专家（课标问题→课程标准主笔；教案/授课计划问题→教案主笔）。")
    else:
        lines.append("1. 无 ❌ 项。⚠️ 项由用户定夺是否修改。")
    if manual:
        lines.append("3. ❔ 项请人工翻到对应位置逐条核对后，在报告上签署确认。")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# 样本生成（供自测与报告形态预览）
# --------------------------------------------------------------------------
def generate_samples(target: Path) -> list[Path]:
    """生成两套样本：`ok/` 合规、`defect/` 注入 6 处已知缺陷。"""
    target.mkdir(parents=True, exist_ok=True)
    out = []
    for sub, defect in (("ok", False), ("defect", True)):
        d = target / sub
        d.mkdir(parents=True, exist_ok=True)
        out += _sample_cs(d, defect) + _sample_lesson(d, defect) + _sample_schedule(d, defect)
    return out


COURSE = "嵌入式Linux应用"
COURSE_WRONG = "嵌入式Linux应用基础"   # 缺陷：课程名不一致


def _sample_cs(d: Path, defect: bool) -> list[Path]:
    from docx import Document
    doc = Document()
    doc.add_paragraph(f"《{COURSE}》课程标准")
    doc.add_paragraph("课程类别：专业核心课")
    doc.add_paragraph("适用专业：嵌入式技术（职业本科）")
    doc.add_paragraph("授课单位：中德机器人学院")
    doc.add_paragraph("学分：4")
    doc.add_paragraph("学时：64")
    doc.add_paragraph("编写执笔人及编写日期：郑洪英 2026年9月10日")
    doc.add_paragraph("审定负责人及审定日期：李主任 2026年9月12日")
    for kw in SECTION_KEYWORDS:
        doc.add_paragraph(f"（示例）{kw}章节正文内容。")
    # 三、模块与学时分配表
    t = doc.add_table(rows=4, cols=6)
    head = ["序号", "教学内容", "学时", "讲授", "实践", "其他"]
    rows = [
        ["1", "系统构建与烧录", "16", "8", "8", "0"],
        ["2", "设备驱动开发", "16", "8", "8", "0"],
        ["3", "文件系统与存储", "16", "8", "8", "0"],
    ]
    for j, h in enumerate(head):
        t.cell(0, j).text = h
    for i, r in enumerate(rows, start=1):
        for j, v in enumerate(r):
            t.cell(i, j).text = v
    total = "48" if defect else "64"          # 缺陷：课标学时总计与授课计划不符
    t.cell(3, 0).text = "学时总计"
    t.cell(3, 2).text = total
    # 四、实践教学安排表
    t2 = doc.add_table(rows=3, cols=4)
    for j, h in enumerate(["序号", "实践项目", "学时", "备注"]):
        t2.cell(0, j).text = h
    for i, r in enumerate([["1", "交叉编译环境搭建", "8", "课内"], ["2", "根文件系统制作", "8", "课内"]], start=1):
        for j, v in enumerate(r):
            t2.cell(i, j).text = v
    # 课程思政融入表
    t3 = doc.add_table(rows=4, cols=3)
    for j, h in enumerate(["知识点", "思政融入点", "思政案例"]):
        t3.cell(0, j).text = h
    pts = [
        ["交叉编译", "自主可控", "国产工具链自主攻关"],
        ["设备驱动", "工匠精神", "大国工匠胡双钱"],
        ["文件系统", "标准意识", "国家标准GB/T 制定历程"],
    ]
    if not defect:
        for i, r in enumerate(pts, start=1):
            for j, v in enumerate(r):
                t3.cell(i, j).text = v
    # defect 模式：思政表数据行留空
    p = d / f"课程标准-{COURSE}.docx"
    doc.save(str(p))
    return [p]


def _sample_lesson(d: Path, defect: bool) -> list[Path]:
    from docx import Document
    doc = Document()
    doc.add_paragraph("深圳信息职业技术大学 教案")
    doc.add_paragraph("20 26 年/20 27 年第 1 学期")
    doc.add_paragraph("专业大类：电子与信息大类")
    doc.add_paragraph(f"课程名称：{COURSE_WRONG if defect else COURSE}")   # 缺陷：课程名不一致
    doc.add_paragraph("课程类别：专业核心课")
    doc.add_paragraph("任课班级：嵌入式3-1班")
    doc.add_paragraph("任课教师：郑洪英")
    doc.add_paragraph("所属院部：中德机器人学院")
    t = doc.add_table(rows=6, cols=2)
    pairs = [
        ("教学单元", "项目二 设备驱动开发"),
        ("周次", "第9周"),
        ("时数", "4学时"),
        ("授课班级", "嵌入式3-1班"),
        ("教学目的及要求", "素质目标：养成自主可控意识；能力目标：能编写字符设备驱动"),
        ("实验仪器及教具", "RK3588 开发板、示波器"),
    ]
    for i, (k, v) in enumerate(pairs):
        t.cell(i, 0).text = k
        t.cell(i, 1).text = v
    # 重点/难点（缺陷：重点留空 + 占位符）
    t2 = doc.add_table(rows=2, cols=2)
    t2.cell(0, 0).text = "教学重点"
    t2.cell(0, 1).text = "XXX" if defect else "字符设备驱动的 file_operations 实现"
    t2.cell(1, 0).text = "教学难点"
    t2.cell(1, 1).text = "内核态与用户态数据交互"
    # 教学过程（缺陷：留空）
    t3 = doc.add_table(rows=2, cols=2)
    t3.cell(0, 0).text = "教学过程"
    t3.cell(0, 1).text = "备注"
    if not defect:
        t3.cell(1, 0).text = (
            "一、导入（10分钟）……二、知识讲解（60分钟）：讲解字符设备驱动的注册流程与 "
            "file_operations 结构体；结合国产工具链自主攻关案例，点出自主可控的思政融入点。"
            "三、实训（90分钟）：在 RK3588 开发板上完成 LED 字符设备驱动编写与加载。"
            "四、小结（20分钟）：回顾驱动框架，强调标准意识与工匠精神。"
        )
    t4 = doc.add_table(rows=2, cols=1)
    t4.cell(0, 0).text = "课后作业"
    t4.cell(1, 0).text = "完成驱动模块的 insmod/rmmod 实验报告" if not defect else "（略）"
    p = d / f"教案-第9周-{COURSE}.docx"
    doc.save(str(p))
    return [p]


def _sample_schedule(d: Path, defect: bool) -> list[Path]:
    from docx import Document
    doc = Document()
    doc.add_paragraph("深圳信息职业技术大学 学期授课计划")
    doc.add_paragraph(f"20 26 年/20 27 年第 1 学期")
    doc.add_paragraph(f"课程名称：{COURSE}")
    doc.add_paragraph("课程类别：专业核心课")
    doc.add_paragraph(f"适用专业：{'电子信息工程技术' if defect else '嵌入式技术'}")
    doc.add_paragraph("任课教师：郑洪英")
    doc.add_paragraph("教研室主任签名：李主任")
    doc.add_paragraph("教研室通过日期：2026年9月15日")
    # 表0：学时统计
    t = doc.add_table(rows=2, cols=8)
    for j, h in enumerate(["本学期授课时数", "班次", "本学期教学周数", "本学期周学时数",
                           "本学期计划教学时数", "预计假日缺课时数", "总时数", "其中"]):
        t.cell(0, j).text = h
    for j, v in enumerate(["1", "嵌入式3-1班", "16", "4", "64", "0", "64", "讲授48/实验16"]):
        t.cell(1, j).text = v
    # 表1：周次
    weeks = list(range(1, 17))
    if defect:
        weeks = [w for w in weeks if w != 9]          # 缺陷：周次断档，缺第9周
    t2 = doc.add_table(rows=len(weeks) + 1, cols=8)
    for j, h in enumerate(["周次", "授课日期", "授课章节及内容提要", "课型",
                           "需用时数", "教学平台", "课外作业", "备注"]):
        t2.cell(0, j).text = h
    mods = ["系统构建与烧录", "设备驱动开发", "文件系统与存储"]
    for i, w in enumerate(weeks, start=1):
        r = [str(w), f"第{w}周周一", mods[(w - 1) % 3], "讲授" if w % 2 else "实践",
             "4", "雨课堂", "课后练习", ""]
        for j, v in enumerate(r):
            t2.cell(i, j).text = v
    p = d / f"课程计划-{COURSE}.docx"
    doc.save(str(p))
    return [p]


# --------------------------------------------------------------------------
# 入口
# --------------------------------------------------------------------------
def load_docs(paths: list[Path]) -> tuple[dict, list[str], dict]:
    try:
        from docx import Document
    except ImportError:
        print("缺少 python-docx，无法读取 .docx。请先运行 scripts/check_environment.py 并按提示安装。",
              file=sys.stderr)
        sys.exit(2)
    docs: dict = {"course-standard": None, "lesson": [], "schedule": None, "unknown": []}
    desc, kind_of = [], {}
    for p in paths:
        if not p.is_file():
            print(f"跳过（不存在）：{p}", file=sys.stderr)
            continue
        try:
            doc = Document(str(p))
        except Exception as e:                                    # noqa: BLE001
            print(f"跳过（无法解析）：{p} — {e}", file=sys.stderr)
            continue
        di = DocInfo(p, doc)
        kind_of[di.name] = KIND_CN.get(di.kind, di.kind)
        desc.append(f"{di.name}（{KIND_CN.get(di.kind, di.kind)}）")
        if di.kind == "lesson":
            docs["lesson"].append(di)
        elif di.kind in docs:
            docs[di.kind] = di
        else:
            docs["unknown"].append(di)
    return docs, desc, kind_of


def run_audit(paths: list[Path]):
    """跑完整审核，返回 (findings, summary, desc, kind_of)。供 CLI 与自测共用。"""
    docs, desc, kind_of = load_docs(paths)
    ctr = [0]
    findings: list[Finding] = []
    ordered = ([docs["course-standard"]] if docs["course-standard"] else []) + docs["lesson"] + \
              ([docs["schedule"]] if docs["schedule"] else []) + docs["unknown"]
    for di in ordered:
        findings += check_required(di, ctr)
        findings += check_tables(di, ctr)
    findings += check_cross(docs, ctr)
    findings.sort(key=lambda f: int(f.idx))
    return findings, summarize(findings), desc, kind_of


def discover(dirpath: Path) -> list[Path]:
    exts = {".docx"}
    return sorted(p for p in dirpath.rglob("*") if p.suffix.lower() in exts and not p.name.startswith("~$"))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="教学文件审核（只读）：必备项目 / 表格完整度 / 跨文件一致性")
    ap.add_argument("files", nargs="*", help="待审核的 .docx 文件")
    ap.add_argument("--dir", help="递归审核该目录下的 .docx")
    ap.add_argument("--out", help="Markdown 报告输出路径")
    ap.add_argument("--json", dest="json_out", help="JSON 结果输出路径")
    ap.add_argument("--demo-dir", help="生成合规/缺陷两套样本到此目录后退出")
    ap.add_argument("--quiet", action="store_true", help="不打印控制台摘要")
    args = ap.parse_args(argv)

    if args.demo_dir:
        files = generate_samples(Path(args.demo_dir))
        print(f"已生成 {len(files)} 份样本：")
        for f in files:
            print("  ", f)
        return 0

    paths = [Path(f) for f in args.files]
    if args.dir:
        paths += discover(Path(args.dir))
    paths = [p for p in paths if p.suffix.lower() == ".docx"]
    if not paths:
        ap.error("未提供待审核文件（用位置参数、--dir 或 --demo-dir）")

    findings, s, desc, kind_of = run_audit(paths)

    md = render_markdown(findings, desc, kind_of)
    out_path = Path(args.out) if args.out else Path("审核报告.md")
    out_path.write_text(md, encoding="utf-8")
    if args.json_out:
        Path(args.json_out).write_text(
            json.dumps({"summary": s, "documents": desc,
                        "findings": [asdict(f) for f in findings]}, ensure_ascii=False, indent=2),
            encoding="utf-8")

    if not args.quiet:
        c = s["counts"]
        print("=" * 62)
        print(f"  教学文件审核 · {s['verdict']}")
        print(f"  文件 {len(desc)} 份：{'、'.join(d.split('（')[0] for d in desc)}")
        print(f"  ❌ {c[FAIL]}  ❔ {c[UNVERIFIED]}  ⚠️ {c[WARN]}  ✅ {c[PASS]}  （共 {s['total']} 项）")
        print(f"  报告：{out_path.resolve()}")
        print("=" * 62)
        for f in findings:
            if f.level in (FAIL, WARN):
                icon = "❌" if f.level == FAIL else "⚠️"
                print(f"  {icon} [{f.idx}] {f.doc} · {f.item}：{f.actual}")
    return 1 if s["counts"][FAIL] else 0


if __name__ == "__main__":
    sys.exit(main())
