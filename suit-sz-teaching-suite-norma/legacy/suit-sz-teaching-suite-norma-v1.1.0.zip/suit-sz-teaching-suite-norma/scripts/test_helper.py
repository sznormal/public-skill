from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
import os, tempfile

def set_run_font(run, cn='仿宋', size=16, bold=False):
    run.font.name = cn; run.font.size = Pt(size); run.bold = bold
    rpr = run._element.get_or_add_rPr()
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = rpr.makeelement(qn('w:rFonts'), {}); rpr.append(rf)
    for a in ('w:eastAsia','w:ascii','w:hAnsi'):
        rf.set(qn(a), cn)

def set_first_line_chars(p, chars=200):
    pPr = p._p.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        ind = pPr.makeelement(qn('w:ind'), {}); pPr.append(ind)
    ind.set(qn('w:firstLineChars'), str(chars))
    if ind.get(qn('w:firstLine')) is not None:
        del ind.attrib[qn('w:firstLine')]

def _para(doc, align=None, indent=True):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    p.paragraph_format.line_spacing = Pt(28)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    if not indent:
        pPr = p._p.get_or_add_pPr()
        ind = pPr.find(qn('w:ind'))
        if ind is None:
            ind = pPr.makeelement(qn('w:ind'), {}); pPr.append(ind)
    else:
        set_first_line_chars(p)
    if align is not None:
        p.alignment = align
    return p

def add_header(doc, segments):
    p = _para(doc, indent=False)
    for label, value in segments:
        set_run_font(p.add_run(label), '仿宋', 16, True)   # 标签仿宋加黑
        set_run_font(p.add_run(value), '仿宋', 16, False)  # 值仿宋不加黑
    return p

def add(doc, text, kind='body'):
    if kind == 'title':
        p = _para(doc, align=WD_ALIGN_PARAGRAPH.CENTER, indent=False); set_run_font(p.add_run(text), '黑体', 22, False)
    elif kind == 'h1':
        p = _para(doc, indent=False); set_run_font(p.add_run(text), '黑体', 16, False)
    elif kind == 'h2':
        p = _para(doc, indent=True); set_run_font(p.add_run(text), '楷体', 16, False)
    else:
        p = _para(doc, indent=True); set_run_font(p.add_run(text), '仿宋', 16, False)
    return p

doc = Document()
add_header(doc, [('课程类别：', '专业拓展课（校企合作开发，线上线下混合式教学）')])
add_header(doc, [('适用专业：', '智能机器人技术（三年制）    '), ('授课单位：', '中德机器人学院')])
add_header(doc, [('学分：', '4                    '), ('学时：', '64')])
add_header(doc, [('编写执笔人及编写日期：', '郑洪英    2026/08/27')])
add_header(doc, [('审定负责人及审定日期：', '赖周艺    2026/09/01')])
add(doc, '《机器人编程与仿真》课程标准', kind='title')
add(doc, '一、课程定位和课程设计', kind='h1')
add(doc, '（一）课程性质', kind='h2')
add(doc, '正文示例：本课程是智能机器人技术专业的专业拓展课。')

out = os.path.join(tempfile.gettempdir(), 'skill_header_test.docx')
doc.save(out)

def rinfo(r):
    rf = r._element.find(qn('w:rPr'))
    ea = None; bold = '0'
    if rf is not None:
        rfonts = rf.find(qn('w:rFonts'))
        if rfonts is not None:
            ea = rfonts.get(qn('w:eastAsia'))
        b = rf.find(qn('w:b'))          # <w:b/> 或 <w:b w:val="true"/> 均表示加粗
        if b is not None:
            val = b.get(qn('w:val'))
            bold = '0' if val in ('false', '0') else '1'
    return ea, bold

ok = True
for p in Document(out).paragraphs:
    t = p.text
    if t.startswith(('课程类别', '适用专业', '学分', '编写执笔人', '审定负责人')):
        for r in p.runs:
            if not r.text.strip():
                continue
            ea, bold = rinfo(r)
            is_label = r.text.endswith('：')
            exp_bold = '1' if is_label else '0'
            good = (ea == '仿宋' and bold == exp_bold)
            if not good:
                ok = False
            print(f"[{'OK' if good else 'FAIL'}] 头部run={r.text!r} font={ea} bold={bold} (期望 仿宋/bold={exp_bold})")
    elif t.startswith('一、'):
        ea, bold = rinfo(p.runs[0])
        good = (ea == '黑体' and bold == '0')
        if not good: ok = False
        print(f"[{'OK' if good else 'FAIL'}] 一级 font={ea} bold={bold}")
    elif t.startswith('（一）'):
        ea, bold = rinfo(p.runs[0])
        good = (ea == '楷体' and bold == '0')
        if not good: ok = False
        print(f"[{'OK' if good else 'FAIL'}] 二级 font={ea} bold={bold}")

print('ALL OK' if ok else 'HAS FAIL')
