#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
环境自检：判断本技能应以哪一级能力运行。

用法：
    python scripts/check_environment.py [--install] [--strict]

设计原则（重要）：
    本脚本 **默认永不阻断流程**。缺包只意味着降级，不意味着停工。
    - L1 完整：python-docx 可用 → 生成排版对齐模板的 .docx
    - L2 Markdown：python-docx 缺失 → 用 export_markdown.py 产出 .md + 版式对照表
    - L3 纯文本：连文件写入都受限 → 直接在对话中输出结构化内容

参数：
    --install   尝试自动 pip 安装缺失的必需包（需联网且有权限；失败不影响降级判定）
    --strict    仅在明确要求"缺包即失败"的调试场景使用，此时缺必需包才返回退出码 1

退出码：默认恒为 0。--strict 且缺必需包时为 1。
"""
from __future__ import annotations

import argparse
import importlib
import subprocess
import sys

REQUIRED = [
    ("docx", "python-docx"),      # 生成/解析 .docx，决定 L1 还是 L2
    ("openpyxl", "openpyxl"),     # 表格数据读写
    ("olefile", "olefile"),       # 老版 .doc (OLE2) 提取
]
OPTIONAL = [
    ("fitz", "pymupdf"),          # PDF 逐页渲染检查
]


def has(mod: str) -> bool:
    try:
        importlib.import_module(mod)
        return True
    except Exception:
        return False


def try_install(pkgs: list[str]) -> bool:
    """尝试自动安装，失败静默返回 False（绝不抛异常打断流程）。"""
    if not pkgs:
        return True
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-q", *pkgs],
            check=True, timeout=180,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        return True
    except Exception:
        return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--install", action="store_true", help="尝试自动安装缺失的必需包")
    ap.add_argument("--strict", action="store_true", help="缺必需包时返回退出码 1")
    args = ap.parse_args()

    print("=" * 60)
    print(" 教学文件写作套件 · 环境自检")
    print("=" * 60)

    missing_required: list[str] = []
    for mod, pkg in REQUIRED:
        ok = has(mod)
        print(f"  [{'OK     ' if ok else 'MISSING'}] {pkg}")
        if not ok:
            missing_required.append(pkg)

    print("  " + "-" * 56)
    for mod, pkg in OPTIONAL:
        ok = has(mod)
        print(f"  [{'OK     ' if ok else 'SKIP   '}] {pkg}（可选）")

    # 自动安装（仅在用户显式要求时）
    if args.install and missing_required:
        print("\n  尝试自动安装缺失包…")
        if try_install(missing_required):
            missing_required = [p for p in missing_required
                                if not has({"python-docx": "docx", "openpyxl": "openpyxl",
                                            "olefile": "olefile"}[p])]
            if not missing_required:
                print("  安装成功 ✅")

    # 判定运行级别
    print("\n" + "=" * 60)
    if not missing_required:
        level = "L1"
        print("  运行级别：L1 · 完整能力")
        print("  → 可直接生成排版对齐模板的 .docx。")
    elif "python-docx" in missing_required:
        level = "L2"
        print("  运行级别：L2 · Markdown 降级")
        print("  → python-docx 不可用，改用零依赖脚本产出 Markdown + 版式对照表：")
        print("      python scripts/export_markdown.py --data <草稿.json> --type standard --out <输出.md>")
        print("  → 用户把内容粘贴进本校 Word 模板，按对照表设置字体/字号/缩进即可。")
        if args.install:
            print("  → 自动安装未成功；如需 L1，请手动执行：")
            print(f"      {sys.executable} -m pip install {' '.join(missing_required)}")
    else:
        level = "L3 或 L1"
        print("  运行级别：L1（部分可选能力受限）")
        print("  → docx 可用，正常生成；个别功能（如老版 .doc 解析）会跳过。")

    print(f"\n  提示：无论级别如何都请继续完成任务，按 {level} 方式交付即可。")
    print("=" * 60)

    if args.strict and missing_required:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
