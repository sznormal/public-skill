# AFP-SPEC 合规证书 · suit-sz-teaching-suite-norma

| 项目 | 内容 |
|---|---|
| Skill 名称 | suit-sz-teaching-suite-norma |
| 领域 | 教育培训（Edu / Teaching Docs） |
| 架构模式 | Pattern 5 · Orchestrated Independent Collection（薄路由主控 + stages/ 按需 Read） |
| 合规等级 | **Silver** |
| 版本 | 1.0.0 |
| 日期 | 2026-08-30 |
| 维护者 | norma（中德机器人学院 / 深圳信息职业技术大学） |

## 合规项自检

### Bronze 基线
- [x] 有明确 frontmatter（name / version / description / 触发词 / 触发隔离）
- [x] 单一明确职责（教学公文撰写与自查闭环）
- [x] 触发词覆盖 12+ 变体，含触发隔离声明
- [x] 落盘思维：每阶段产物写具名文件

### Silver 增强
- [x] **薄路由主控**：SKILL.md < 2500 token，仅做意图识别与分流，详情延迟到 stages/
- [x] **按需 Read**：modules/、references/ 仅在用户特殊指令或对应阶段加载
- [x] **触发词隔离**：frontmatter 明确"只在用户表达…意图时触发"，并列明不处理场景
- [x] **状态管理 + 断点续传**：HUD JSON 写盘到项目目录，`Continue <项目路径>` 跨对话续跑
- [x] **Hard Stop 确认**：每个阶段结束有确认门（头部信息确认门、范围确认门、督导只读）
- [x] **领域自适应**：含教育培训领域专属模块（sziit-format、politics-integration）
- [x] **阶段化结构**：P1 意图 → P2 课标 → P3 教案/授课计划 → P4 督导

### 反模式规避
- [x] 无命名空间前缀缺失（suit-sz-teaching-suite-norma 含归属标识）
- [x] 主控未塞满内容（详情在 stages/，主控只路由）
- [x] 触发词已预检隔离（与通用 Word 排版、其他领域 skill 不冲突）
- [x] 关键步骤产物落盘（JSON / docx / 督导报告均为具名文件）
- [x] 决策点 Hard Stop（确认门不可跳过）

## 与 AFP 生态关系

本 skill 为 norma 个人教学工作流私有技能，采用 Bronze/Silver 工程规范。未强制接入 AFP-shared-primitives 层（排版为深信院专属规范，无跨合伙人通用价值），故不申请 Gold 级 Shared Primitive 复用。如需贡献到 AFP-ecosystem，可将 `modules/politics-integration.md`（思政点→教学过程映射）抽象为 `afp-shared-edu-politics-mapping` 候选 primitive。

---
*依据 AFP-SPEC v0.1 自评 · 最终评审以官方为准*
