#!/usr/bin/env python3
"""模板版式提取：把一份 docx 模板的真实排版规范提取为机器可读基线。

用法:
    python extract_template.py <模板.docx> \\
        --doc-type course-standard|lesson|schedule|auto \\
        --out 版式规范.json --markdown 版式规范.md --against-builtin

设计要点:
- 中文字体只认 w:rFonts/@w:eastAsia（run.font.name 只反映西文）
- 首行缩进优先读 w:firstLineChars（百分之一字符，200 = 2 字符），缺失时回退 w:firstLine（twips）折算
- 行距直接读 w:spacing/@w:line + @w:lineRule，避免 python-docx 的自动换算歧义
- 合并单元格按底层 w:tc 对象身份去重，还原真实网格（row.cells 会重复返回合并格）
- 角色格式按「逐维度取众数」聚合，避免个别离群段（如表标题混入正文角色）污染整类格式
- 只读模板，绝不修改源文件
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

try:
    from docx import Document
    from docx.oxml.ns import qn
except ImportError:  # pragma: no cover
    sys.stderr.write(
        "ERROR: 缺少 python-docx，无法提取模板版式。\n"
        "请先运行 scripts/check_environment.py 找到可用解释器，"
        "或按 references/setup-guide.md 安装依赖。\n"
    )
    sys.exit(3)

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_TEMPLATES_DIR = SCRIPT_DIR.parent / "templates"

BUILTIN_BY_DOC_TYPE = {
    "course-standard": "课程标准.docx",
    "lesson": "教案模板.docx",
    "schedule": "课程计划-空白模板.docx",
}

# ---------------------------------------------------------------- 角色推断

RE_DOC_TITLE = re.compile(r"^《?.{2,40}》?\s*(课程标准|教学大纲|标准)$")
RE_H1 = re.compile(r"^[一二三四五六七八九十]+[、.．]")
RE_H2 = re.compile(r"^[（(][一二三四五六七八九十]+[）)]")
RE_H3 = re.compile(r"^\d+(\.\d+)*[、.．]?\s*\S")
RE_CAPTION_NUM = re.compile(r"^(表|图)\s*\d+")
RE_CAPTION_SUFFIX = re.compile(r"^[^\s（()]{1,14}(表|图)$")   # 如「学时分配表」
RE_LABEL = re.compile(r"^[^：:]{2,14}[：:]")
RE_COVER = re.compile(r"(教案|课程计划|授课计划|教学进度)")

# 模板里残留的提示文字
HINT_KEYWORDS = ("以下内容", "不限于", "特别是", "请填写", "可选", "如：", "例如", "…", "...")
RE_HINT_PAREN = re.compile(r"^[（(].{0,120}[）)]$")
RE_TYPE_HINT = re.compile(
    r"[（(][^）)]{0,24}(字体|字号|三号|四号|小四|五号|二号|小二|小三|宋体|黑体|仿宋|楷体)[^）)]{0,24}[）)]"
)


def infer_role(text: str, align: str | None, size_pt: float | None, index: int) -> str:
    """按文本形态 + 对齐 + 位置推断元素角色。"""
    t = text.strip()
    if not t:
        return "empty"
    if RE_DOC_TITLE.match(t):
        return "doc-title"
    if RE_H1.match(t):
        return "h1"
    if RE_H2.match(t):
        return "h2"
    if RE_CAPTION_NUM.match(t):
        return "caption"
    if align == "CENTER" and RE_CAPTION_SUFFIX.match(t):
        return "caption"
    if index < 30 and RE_LABEL.match(t) and len(t) < 60:
        return "header-label"
    if RE_H3.match(t):
        return "h3"
    if RE_HINT_PAREN.match(t):
        return "hint"
    if RE_COVER.search(t) and size_pt and size_pt >= 15:
        return "cover-title"
    return "body"


# ---------------------------------------------------------------- 格式读取


def run_font(run, fallback_style=None) -> dict:
    """读取单个 run 的中文字体/字号/字重/下划线。"""
    rPr = run._element.find(qn("w:rPr"))
    east, ascii_font = None, None
    if rPr is not None:
        rFonts = rPr.find(qn("w:rFonts"))
        if rFonts is not None:
            east = rFonts.get(qn("w:eastAsia"))
            ascii_font = rFonts.get(qn("w:ascii"))
    name = run.font.name or ascii_font
    size = run.font.size.pt if run.font.size is not None else None
    if size is None and fallback_style is not None:
        try:
            size = fallback_style.font.size.pt if fallback_style.font.size else None
        except Exception:
            size = None
    return {
        "font_east_asia": east,
        "font_ascii": ascii_font or name,
        "size_pt": size,
        "bold": run.font.bold,
        "underline": run.font.underline,
    }


def para_format(p) -> dict:
    """读取段落格式：对齐、首行缩进、行距、段前段后。"""
    pPr = p._p.find(qn("w:pPr"))
    out = {
        "align": str(p.alignment).split(" ")[0] if p.alignment is not None else None,
        "first_line_chars": None,
        "first_line_indent_pt": None,
        "line_spacing": {"rule": None, "pt": None},
        "space_before_pt": None,
        "space_after_pt": None,
    }
    if pPr is None:
        return out

    ind = pPr.find(qn("w:ind"))
    if ind is not None:
        flc = ind.get(qn("w:firstLineChars"))
        fl = ind.get(qn("w:firstLine"))
        if flc is not None:
            out["first_line_chars"] = int(flc)
        elif fl is not None:
            out["first_line_indent_pt"] = round(int(fl) / 20.0, 2)

    sp = pPr.find(qn("w:spacing"))
    if sp is not None:
        line, rule = sp.get(qn("w:line")), sp.get(qn("w:lineRule"))
        if line is not None:
            v = int(line)
            if rule in ("exact", "atLeast"):
                out["line_spacing"] = {
                    "rule": "EXACTLY" if rule == "exact" else "AT_LEAST",
                    "pt": round(v / 20.0, 2),
                }
            else:
                out["line_spacing"] = {"rule": "MULTIPLE", "pt": round(v / 240.0, 3)}
        for key, tag in (("space_before_pt", "w:before"), ("space_after_pt", "w:after")):
            val = sp.get(qn(tag))
            if val is not None:
                out[key] = round(int(val) / 20.0, 2)
    return out


def header_label_runs(p) -> list[dict]:
    """头部信息栏：区分加黑标签 run 与不加黑值 run。"""
    got = []
    for r in p.runs:
        t = r.text
        if not t.strip():
            continue
        got.append({
            "text": t[:30],
            "is_label": t.strip().endswith(("：", ":")),
            "bold": r.font.bold,
            "font_east_asia": run_font(r)["font_east_asia"],
        })
    return got


def page_info(doc) -> dict:
    s = doc.sections[0]
    return {
        "width_pt": round(s.page_width.pt, 2) if s.page_width else None,
        "height_pt": round(s.page_height.pt, 2) if s.page_height else None,
        "margin_left_pt": round(s.left_margin.pt, 2) if s.left_margin else None,
        "margin_right_pt": round(s.right_margin.pt, 2) if s.right_margin else None,
        "margin_top_pt": round(s.top_margin.pt, 2) if s.top_margin else None,
        "margin_bottom_pt": round(s.bottom_margin.pt, 2) if s.bottom_margin else None,
    }


# ---------------------------------------------------------------- 角色格式聚合

NONE_TOKEN = "__NONE__"


def _token(v):
    """把格式值转成可哈希、可统计的 token。"""
    if v is None:
        return NONE_TOKEN
    if isinstance(v, float):
        return round(v, 2)
    return v


def _untoken(v):
    return None if v == NONE_TOKEN else v


def summarize_role(items: list[dict]) -> dict:
    """逐维度取众数（而非整条记录取众数），避免离群段污染整类格式。"""
    def mode(values):
        toks = [t for t in (_token(v) for v in values) if t is not None]
        if not toks:
            return None, 0.0
        c = Counter(toks)
        top, n = c.most_common(1)[0]
        return _untoken(top), round(n / len(toks), 3)

    fonts = mode([it["font_east_asia"] for it in items])
    sizes = mode([it["size_pt"] for it in items])
    bolds = mode([it["bold"] for it in items])
    aligns = mode([it["align"] for it in items])
    flcs = mode([it["first_line_chars"] for it in items])
    sbs = mode([it.get("space_before_pt") for it in items])
    sas = mode([it.get("space_after_pt") for it in items])

    ls_pairs = []
    for it in items:
        ls = it.get("line_spacing") or {}
        if ls.get("rule"):
            ls_pairs.append((ls["rule"], ls["pt"]))
    if ls_pairs:
        (ls_rule, ls_pt), ls_n = Counter(ls_pairs).most_common(1)[0]
        ls_conf = round(ls_n / len(ls_pairs), 3)
    else:
        ls_rule, ls_pt, ls_conf = None, None, 0.0

    # 代表段：与各维度众数吻合度最高的那一段，作为示例文本
    def score(it):
        s = 0
        if it["font_east_asia"] == fonts[0]:
            s += 1
        if it["size_pt"] == sizes[0]:
            s += 1
        if (it.get("line_spacing") or {}).get("rule") == ls_rule:
            s += 1
        if it["first_line_chars"] == flcs[0]:
            s += 1
        return s

    rep = max(items, key=score) if items else {}

    return {
        "sample_count": len(items),
        "text_sample": rep.get("text", "")[:40],
        "font_east_asia": fonts[0],
        "font_confidence": fonts[1],
        "size_pt": sizes[0],
        "size_confidence": sizes[1],
        "bold": bolds[0],
        "align": aligns[0],
        "first_line_chars": flcs[0],
        "first_line_indent_pt": mode([it.get("first_line_indent_pt") for it in items])[0],
        "line_spacing": {"rule": ls_rule, "pt": ls_pt, "confidence": ls_conf},
        "space_before_pt": sbs[0],
        "space_after_pt": sas[0],
    }


# ---------------------------------------------------------------- 表格


def table_grid(table) -> list[list[str]]:
    """还原合并后的真实网格：按底层 w:tc 身份去重相邻重复格。"""
    grid = []
    for row in table.rows:
        seen, cells = [], []
        for c in row.cells:
            tc = c._tc
            if not seen or seen[-1] is not tc:
                cells.append(c)
                seen.append(tc)
        grid.append([c.text.strip().replace("\n", " / ") for c in cells])
    return grid


def table_info(table, index: int, caption: str | None) -> dict:
    grid = table_grid(table)
    cells = []
    for ri, row in enumerate(table.rows):
        seen = []
        merged_in_row = len({id(c._tc) for c in row.cells}) < len(row.cells)
        for c in row.cells:
            if seen and seen[-1] is c._tc:
                continue
            seen.append(c._tc)
            txt = c.text.strip()
            first = None
            for p in c.paragraphs:
                for r in p.runs:
                    if r.text.strip():
                        first = run_font(r)
                        break
                if first:
                    break
            cells.append({
                "r": ri, "c": len(seen) - 1, "text": txt[:40],
                "is_label": bool(txt) and (txt.endswith(("：", ":")) or len(txt) <= 8),
                "row_has_merged_cells": merged_in_row,
                "font_east_asia": (first or {}).get("font_east_asia"),
                "size_pt": (first or {}).get("size_pt"),
                "bold": (first or {}).get("bold"),
            })
    return {
        "index": index,
        "rows": len(table.rows),
        "cols": max((len(r) for r in grid), default=0),
        "caption": caption,
        "grid": grid[:12],
        "cells": cells[:160],
    }


# ---------------------------------------------------------------- 主提取


def extract(path: Path, doc_type: str = "auto") -> dict:
    doc = Document(str(path))
    try:
        style = doc.styles["Normal"]
    except KeyError:
        style = None

    if doc_type == "auto":
        for dt, fname in BUILTIN_BY_DOC_TYPE.items():
            if path.name == fname:
                doc_type = dt
                break
        else:
            joined = " ".join(p.text for p in doc.paragraphs[:40])
            if RE_COVER.search(joined):
                doc_type = "schedule" if ("课程计划" in joined or "授课计划" in joined) else "lesson"
            else:
                doc_type = "course-standard"

    paragraphs, role_buckets = [], {}
    labels, cleanup, header_runs = [], [], []

    for i, p in enumerate(doc.paragraphs):
        text = p.text.strip()
        if not text:
            continue
        runs = [r for r in p.runs if r.text.strip()]
        if not runs:
            continue
        main = run_font(runs[0], style)
        fmt = para_format(p)
        role = infer_role(text, fmt["align"], main["size_pt"], i)

        item = {
            "index": i,
            "text": text[:60],
            "role": role,
            "font_east_asia": main["font_east_asia"],
            "size_pt": main["size_pt"],
            "bold": main["bold"],
            **fmt,
        }
        paragraphs.append(item)
        role_buckets.setdefault(role, []).append(item)

        if role == "header-label":
            labels.append(text[:30])
            header_runs.extend(header_label_runs(p))
        if RE_TYPE_HINT.search(text):
            cleanup.append(RE_TYPE_HINT.search(text).group(0)[:80])
        if role == "hint":
            cleanup.append(text[:80])

    # 表格内的提示文字与表标题
    table_captions = []
    for ti, t in enumerate(doc.tables):
        cap = None
        if t.rows and t.rows[0].cells:
            for p in t.rows[0].cells[0].paragraphs:
                txt = p.text.strip()
                if txt and RE_HINT_PAREN.match(txt):
                    cleanup.append("[表格内] " + txt[:80])
        table_captions.append(cap)

    roles = {r: summarize_role(items)
             for r, items in role_buckets.items() if r not in ("empty", "hint")}
    tables = [table_info(t, i, table_captions[i]) for i, t in enumerate(doc.tables)]

    return {
        "source": {
            "file": str(path),
            "kind": "builtin-default" if path.parent == DEFAULT_TEMPLATES_DIR else "user-template",
            "doc_type": doc_type,
            "extracted_with": "python-docx",
        },
        "page": page_info(doc),
        "roles": roles,
        "paragraph_samples": paragraphs[:40],
        "tables": tables,
        "labels": sorted(set(labels)),
        "header_runs": header_runs[:60],
        "cleanup_notes": sorted(set(cleanup)),
        "unverified": [],
    }


def diff_specs(user: dict, builtin: dict) -> list[dict]:
    """逐角色比对两份版式基线，标出影响等级。"""
    diffs = []
    high_keys = ("font_east_asia", "size_pt", "first_line_chars", "line_spacing")
    for role, ub in user.get("roles", {}).items():
        bb = builtin.get("roles", {}).get(role)
        if not bb:
            diffs.append({"item": f"{role}（内置基线无此角色）", "user": "存在",
                          "builtin": "—", "impact": "low"})
            continue
        for k in high_keys + ("bold", "align"):
            uv, bv = ub.get(k), bb.get(k)
            if k == "first_line_chars":
                # None 与 0 都表示顶格，视为等价
                if (uv or 0) == (bv or 0):
                    continue
            if k == "line_spacing":
                uv = (uv or {}).get("rule"), (uv or {}).get("pt")
                bv = (bv or {}).get("rule"), (bv or {}).get("pt")
            if uv != bv:
                diffs.append({
                    "item": f"{role} · {k}",
                    "user": json.dumps(uv, ensure_ascii=False),
                    "builtin": json.dumps(bv, ensure_ascii=False),
                    "impact": "high" if k in high_keys else "low",
                })
    return diffs


# ---------------------------------------------------------------- 输出


def to_markdown(spec: dict) -> str:
    lines, n = [], 0
    src = spec["source"]
    lines.append(f"# 版式规范 · {Path(src['file']).name}")
    lines.append("")
    lines.append(f"- 来源类型：`{src['kind']}`")
    lines.append(f"- 文档类型：`{src['doc_type']}`")
    pg = spec["page"]
    lines.append(f"- 页面：{pg['width_pt']}×{pg['height_pt']} pt，"
                 f"页边距 左{pg['margin_left_pt']} 右{pg['margin_right_pt']} "
                 f"上{pg['margin_top_pt']} 下{pg['margin_bottom_pt']} pt")
    lines.append("")

    n += 1
    lines.append(f"## {n}、各角色格式")
    lines.append("")
    lines.append("| 角色 | 字体(eastAsia) | 字号 | 加粗 | 对齐 | 首行缩进 | 行距 | 样本数 | 示例 |")
    lines.append("|---|---|---|---|---|---|---|---|---|")
    for role, r in spec["roles"].items():
        flc = r["first_line_chars"]
        if flc in (None, 0):
            indent = "顶格"
        else:
            indent = f"{int(flc) / 100:g} 字符"
        if flc is None and r.get("first_line_indent_pt"):
            indent = f"≈{r['first_line_indent_pt']} pt"
        ls = r["line_spacing"]
        ls_txt = f"{ls['rule']} {ls['pt']}" if ls.get("rule") else "—"
        lines.append(
            f"| `{role}` | {r['font_east_asia'] or '—'} | "
            f"{r['size_pt'] if r['size_pt'] is not None else '—'} | "
            f"{r['bold']} | {r['align'] or '—'} | {indent} | {ls_txt} | "
            f"{r['sample_count']} | {r['text_sample'][:22]} |"
        )
    lines.append("")

    if spec.get("tables"):
        n += 1
        lines.append(f"## {n}、表格结构")
        lines.append("")
        for t in spec["tables"]:
            lines.append(f"### 表格{t['index']}：{t['rows']} 行 × {t['cols']} 列")
            lines.append("")
            grid = t["grid"]
            if grid:
                width = max(len(r) for r in grid)
                lines.append("| " + " | ".join(f"c{i}" for i in range(width)) + " |")
                lines.append("|" + "---|" * width)
                for row in grid:
                    pad = row + [""] * (width - len(row))
                    lines.append("| " + " | ".join(x.replace("|", "/")[:24] for x in pad) + " |")
            lines.append("")

    if spec.get("labels"):
        n += 1
        lines.append(f"## {n}、固定标签清单")
        lines.append("")
        for lb in spec["labels"]:
            lines.append(f"- `{lb}`")
        lines.append("")

    if spec.get("cleanup_notes"):
        n += 1
        lines.append(f"## {n}、待清理的模板提示文字")
        lines.append("")
        for c in spec["cleanup_notes"]:
            lines.append(f"- {c}")
        lines.append("")

    if spec.get("diff_vs_builtin"):
        n += 1
        lines.append(f"## {n}、与内置默认基线的差异")
        lines.append("")
        lines.append("| 项目 | 本模板 | 内置默认 | 影响 |")
        lines.append("|---|---|---|---|")
        for d in spec["diff_vs_builtin"]:
            lines.append(f"| {d['item']} | {d['user']} | {d['builtin']} | {d['impact']} |")
        lines.append("")
        lines.append("> `high` = 字体族/字号/缩进/行距差异，必须按本模板执行；`low` = 对齐/字重差异，可参考。")
        lines.append("")

    if spec.get("unverified"):
        n += 1
        lines.append(f"## {n}、未能验证的项")
        lines.append("")
        for u in spec["unverified"]:
            lines.append(f"- {u}")
        lines.append("")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="提取 docx 模板的版式规范")
    ap.add_argument("template", help="模板文件路径（.docx）")
    ap.add_argument("--doc-type", default="auto",
                    choices=["auto", "course-standard", "lesson", "schedule"])
    ap.add_argument("--out", help="输出 JSON 路径（默认与模板同目录）")
    ap.add_argument("--markdown", help="输出 Markdown 路径（默认与 JSON 同名 .md）")
    ap.add_argument("--against-builtin", action="store_true",
                    help="与内置默认模板基线逐项比对")
    ap.add_argument("--templates-dir", default=str(DEFAULT_TEMPLATES_DIR),
                    help="内置模板目录")
    args = ap.parse_args()

    path = Path(args.template).expanduser().resolve()
    if not path.is_file():
        sys.stderr.write(f"ERROR: 模板不存在：{path}\n")
        return 2
    if path.suffix.lower() == ".doc":
        sys.stderr.write(
            "ERROR: 这是旧版 .doc（OLE2 二进制），无法可靠提取格式。\n"
            "请用 scripts/doc_extract.py 取文本，或让用户另存为 .docx 后重试。\n"
        )
        return 4

    spec = extract(path, args.doc_type)

    if args.against_builtin:
        fname = BUILTIN_BY_DOC_TYPE.get(spec["source"]["doc_type"])
        bp = Path(args.templates_dir) / fname if fname else None
        if bp and bp.is_file() and bp.resolve() != path:
            spec["diff_vs_builtin"] = diff_specs(spec, extract(bp, spec["source"]["doc_type"]))
        else:
            spec["unverified"].append("未找到可用的内置基线模板，差异比对跳过（本次提取的即是内置模板）")

    out = Path(args.out) if args.out else path.with_name(f"版式规范-{path.stem}.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")

    md_path = Path(args.markdown) if args.markdown else out.with_suffix(".md")
    md_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.write_text(to_markdown(spec), encoding="utf-8")

    print(f"OK  角色 {len(spec['roles'])} 类，表格 {len(spec['tables'])} 个，"
          f"标签 {len(spec['labels'])} 条，待清理 {len(spec['cleanup_notes'])} 条")
    print(f"JSON     -> {out}")
    print(f"Markdown -> {md_path}")
    if spec.get("diff_vs_builtin"):
        hi = sum(1 for d in spec["diff_vs_builtin"] if d["impact"] == "high")
        print(f"差异     -> {len(spec['diff_vs_builtin'])} 项（其中 high {hi} 项）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
