---
name: "suit-sz-teaching-suite-norma"
version: "1.0.0"
display_name: "深信院教学文件写作套件（统一版）"
display_name_en: "SZIIT Teaching Document Suite (Unified)"
description_zh: >
  面向深圳信息职业技术大学的教学公文一站式写作技能。一个技能内闭环完成三类文档的撰写与自查：
  撰写《课程标准》（含课程思政融入表）、以课标为输入生成教案与学期授课计划、
  并对三份文件做版本 / 格式 / 内容 / 互相匹配的一致性督导检查。
description_en: >
  An all-in-one authoring skill for teaching documents at Shenzhen Institute of Information Technology.
  It drafts the Course Standard (including the ideological and political education integration table),
  generates lesson plans and the semester teaching schedule from that standard, and runs a supervisor
  check covering version, formatting, content and cross-document consistency.
description: >
  深圳信息职业技术大学（深信院）"教学文件写作套件"统一技能。覆盖《课程标准》撰写、教案 + 学期授课计划撰写、
  以及三份文件（课标/教案/授课计划）的一致性督导检查，一个技能内闭环。采用 AFP 薄路由 + 按需 Read 架构：
  主控只做意图识别与分流，详细流程延迟加载到 stages/ 子文档。
  【触发词覆盖】：写课程标准 / 课标排版 / 套用课标模板 / 根据大纲生成课标 / 写教案 / 写授课计划 /
                 学期授课计划表 / 教学进度表 / 根据课标生成教案 / 写教学文件 / 教学文档套件 /
                 督导检查 / 检查三份文件一致性 / 课标教案授课计划对一对 / 教学文件自查
  【触发隔离】：只在用户表达"撰写/生成/排版/检查 课标·教案·授课计划 类教学公文"意图时触发。
               普通文档（报告/论文/公函/简历）美化、单页讲义、PPT、非深信院版式文档不触发，转通用排版。
  【与其他 skill 关系】：本技能是 course-standard-writer / teaching-docs-writer / teaching-docs-suite
               三者的合并替代版；部署后旧三者应停用删除。
author: "norma（中德机器人学院 / 深圳信息职业技术大学）"
created: "2026-08-30"
license: "MIT"
agent_created: true
---

# 深信院教学文件写作套件（统一版）

一个技能闭环完成三类教学公文的撰写与自查：**《课程标准》**（设计总纲）→ **教案 + 学期授课计划**（落地执行件）→ **督导检查**（三份文件一致性核对）。

## 核心设计理念（AFP Pattern 5）

1. **薄路由主控**：本文件只做意图识别 + 分流，所有生成/排版/校验逻辑在 `stages/` 子文档，按需 Read。
2. **链路顺序不可乱**：先课标 → 后教案/授课计划 → 最后督导。教案/授课计划必须**以写好的课标为输入**。
3. **思政点贯穿**：教案"教学过程"必须回溯课标《课程思政融入表》的"知识点→思政融入点→思政案例"，见 `modules/politics-integration.md`。
4. **落盘思维**：每阶段实质产物（数据 JSON / 生成的 docx / 督导报告）都写成具名文件，可复用、可交接、可复现。
5. **督导闭环**：交付前由 `stages/04-supervisor.md` 核对版本/格式/内容/三文件一致性，输出检查报告。

## 全局状态管理（HUD，写盘到项目目录）

```json
{
  "meta": { "skill": "suit-sz-teaching-suite-norma", "stage": "intent", "course": "" },
  "artifacts": {
    "course_standard": "", "lesson_plans": [], "teaching_schedule": "",
    "supervisor_report": ""
  },
  "history": { "completed": [], "pending_review": [] }
}
```

## 阶段路由（每阶段 Hard Stop 确认）

| 阶段 | 名称 | 触发关键词 | 加载文档 | 前置 |
|------|------|-----------|---------|------|
| P1 | 意图识别与分流 | 写课标/写教案/写授课计划/督导检查/写教学文件 | `stages/01-intent.md` | 无 |
| P2 | 撰写《课程标准》 | 课标/大纲/课程纲要/标准 | `stages/02-course-standard.md` | P1 路由到课标 |
| P3 | 撰写教案 + 授课计划 | 教案/授课计划/教学进度 | `stages/03-lesson-schedule.md` | 须有课标 .docx |
| P4 | 督导一致性检查 | 督导检查/对一对/自查/一致性 | `stages/04-supervisor.md` | 有 ≥1 份已生成文件 |

> 触发即进入 P1 意图识别；若用户已明确文档类型，直接路由到对应阶段。

## 按需模块

| 用户说 | 加载文档 |
|--------|---------|
| "排版规范是什么" / "字体字号" | `modules/sziit-format.md` |
| "思政点怎么融入教学过程" | `modules/politics-integration.md` |
| "我要提供哪些内容" | `references/teacher-checklist.md` |
| "排版细则/模板解析方法" | `references/format-spec.md` |

## 首次触发引导

```
你好！我是「深信院教学文件写作套件」统一技能（norma 版）。

我可以帮你完成：
  ① 写《课程标准》（课程设计总纲，含课程思政融入表）
  ② 据课标写 教案 + 学期授课计划
  ③ 督导检查：核对版本 / 格式 / 内容 / 三份文件是否互相匹配

请告诉我：你现在想做哪一步？
（如果还不确定，建议从 ① 课程标准 开始，因为教案和授课计划都要以它为输入。）
```

## 通用指令

| 指令 | 功能 |
|------|------|
| `Next` | 当前阶段完成，进入下一步 |
| `Back` | 回到上一阶段修改 |
| `督导` / `检查` | 跳转 P4 督导 |
| `Status` | 输出当前 HUD 状态 |
| `Continue <项目路径>` | 跨对话续跑（从磁盘恢复状态） |

## 依赖与降级

- 必需：python-docx、openpyxl、olefile（渲染/解析课标与大纲）。
- 可选：pymupdf（PDF 逐页校验；缺失则跳过，核心流程不受影响）。
- 写文档前必跑 `scripts/check_environment.py`；缺必需包则提示安装，绝不静默降级。

## 边界

- 仅适用于**深圳信息职业技术大学**公文系模板；其他学校版式须先经使用者确认。
- 不处理单页讲义、PPT、报告、论文、公函等非公文系教学文档。
- 本技能交付后，旧 `course-standard-writer` / `teaching-docs-writer` / `teaching-docs-suite` 应停用删除，避免重复触发。
