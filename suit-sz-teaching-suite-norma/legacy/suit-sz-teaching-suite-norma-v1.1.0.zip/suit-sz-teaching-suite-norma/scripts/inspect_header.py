from docx import Document
from docx.oxml.ns import qn
import sys

if len(sys.argv) < 2:
    print("用法: python assets/inspect_header.py <模板docx路径> [<生成docx路径>]")
    sys.exit(1)
TEMPLATE = sys.argv[1]
GEN = sys.argv[2] if len(sys.argv) > 2 else None


def run_detail(p):
    out = []
    for r in p.runs:
        rf = r._element.find(qn('w:rPr'))
        ea = None
        bold = None
        if rf is not None:
            rfonts = rf.find(qn('w:rFonts'))
            if rfonts is not None:
                ea = rfonts.get(qn('w:eastAsia'))
            b = rf.find(qn('w:b'))
            bold = b.get(qn('w:val')) if b is not None else '0'
        out.append("'%s'[ea=%s,bold=%s]" % (r.text, ea, bold))
    pPr = p._p.find(qn('w:pPr'))
    flc = fli = None
    if pPr is not None:
        ind = pPr.find(qn('w:ind'))
        if ind is not None:
            flc = ind.get(qn('w:firstLineChars'))
            fli = ind.get(qn('w:firstLine'))
    return " | ".join(out), "flc=%s fli=%s" % (flc, fli)


print("=== TEMPLATE 头部信息栏 逐run字体 ===")
d = Document(TEMPLATE)
started = False
for p in d.paragraphs:
    t = p.text.strip()
    if t.startswith(('课程类别', '适用专业', '学分', '编写执笔人', '审定负责人')):
        started = True
        runs, ind = run_detail(p)
        print("")
        print("[%s] indent=%s" % (t[:18], ind))
        print("  runs:", runs)
    elif started and t.startswith(('一、', '《')):
        break

if GEN:
    print("")
    print("=== 生成的文件 头部信息栏 逐run字体 ===")
    d2 = Document(GEN)
    started = False
    for p in d2.paragraphs:
        t = p.text.strip()
        if t.startswith(('课程类别', '适用专业', '学分', '编写执笔人', '审定负责人')):
            started = True
            runs, ind = run_detail(p)
            print("")
            print("[%s] indent=%s" % (t[:18], ind))
            print("  runs:", runs)
        elif started and t.startswith(('一、', '《')):
            break
else:
    print("")
    print("（未提供生成文件路径，已跳过生成文件比对）")
