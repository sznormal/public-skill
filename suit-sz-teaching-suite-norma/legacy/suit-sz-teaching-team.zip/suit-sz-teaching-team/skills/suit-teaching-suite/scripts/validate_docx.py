#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""回读 .docx 校验排版是否合规（只读）。

期望值来源二选一：
  1) --baseline 版式规范.json  → 按用户模板提取出的真实版式校验（推荐）
  2) 无 --baseline              → 按 references/format-rules.md 的默认值校验

校验项：字体族、字号、首行缩进、固定行距、头部信息栏双层 run、
        标题位于表格上方、模板括号提示文字是否清除。

用法：
    python validate_docx.py 课程标准-XXX.docx --baseline 版式规范-XX.json --profile course-standard
    python validate_docx.py 课程标准-XXX.docx --profile course-standard --json
    python validate_docx.py 课程名-教案9.docx --profile lesson

profile：
    course-standard  课标
    lesson           教案
    schedule         授课计划

退出码：全部通过为 0；存在 FAIL 为 1。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from docx import Document                                        # noqa: E402
from docx.oxml.ns import qn                                      # noqa: E402

ALLOWED_FONTS = {
    '黑体', '楷体', '楷体_GB2312', '仿宋', '仿宋_GB2312',
    '方正公文小标宋', '华文中宋', '宋体', '方正小标宋简体',
}
# 同族字体等价映射：模板写「仿宋」而产物用「仿宋_GB2312」不算错
FONT_FAMILY = {
    '仿宋': 'fangsong', '仿宋_GB2312': 'fangsong', 'FangSong': 'fangsong',
    '楷体': 'kaiti', '楷体_GB2312': 'kaiti', 'KaiTi': 'kaiti',
    '黑体': 'heiti', 'SimHei': 'heiti',
    '宋体': 'songti', 'SimSun': 'songti',
    '方正公文小标宋': 'xiaobiaosong', '方正小标宋简体': 'xiaobiaosong', '华文中宋': 'xiaobiaosong',
}
HINT_RE = re.compile(r"（需包括但不限于|（字体三号|采用的教学模式特别是|（以下内容为选填|（含课程思政、职业素养")
RE_H1 = re.compile(r"^[一二三四五六七八九十]+、")
RE_H2 = re.compile(r"^[（(][一二三四五六七八九十]+[）)]")
RE_CAPTION_NUM = re.compile(r"^表\s*\d")
RE_CAPTION_SUFFIX = re.compile(r"^[^\s（()]{1,14}表$")
RE_H3 = re.compile(r"^\d+(\.\d+)*[、.．]?\s*\S")
RE_DOC_TITLE = re.compile(r"^《?.{2,40}》?\s*(课程标准|教学大纲|标准)$")
RE_LABEL = re.compile(r"^[^：:]{2,14}[：:]")
RE_COVER = re.compile(r"(教案|课程计划|授课计划|教学进度)")

# 无 --baseline 时的默认期望值（深信院校版规范）
DEFAULT_EXPECT_COURSE_STANDARD = {
    "doc-title":    {"font_east_asia": "黑体", "size_pt": 22, "first_line_chars": 0, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
    "h1":           {"font_east_asia": "黑体", "size_pt": 16, "first_line_chars": 0, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
    "h2":           {"font_east_asia": "楷体", "size_pt": 16, "first_line_chars": 200, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
    "h3":           {"font_east_asia": "仿宋", "size_pt": 16, "first_line_chars": 200, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
    "body":         {"font_east_asia": "仿宋", "size_pt": 16, "first_line_chars": 200, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
    "caption":      {"font_east_asia": "仿宋", "size_pt": 16, "first_line_chars": 0, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
    "header-label": {"font_east_asia": "仿宋", "size_pt": 16, "first_line_chars": 0, "line_spacing": {"rule": "EXACTLY", "pt": 28}},
}


def font_family(name):
    if not name:
        return None
    return FONT_FAMILY.get(name, name)


def para_indent(p):
    pPr = p._p.find(qn('w:pPr'))
    if pPr is None:
        return None, None
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        return None, None
    return ind.get(qn('w:firstLineChars')), ind.get(qn('w:firstLine'))


def run_font(run):
    rPr = run._element.find(qn('w:rPr'))
    if rPr is None:
        return None, None, None
    rFonts = rPr.find(qn('w:rFonts'))
    east = rFonts.get(qn('w:eastAsia')) if rFonts is not None else None
    size = rPr.find(qn('w:sz'))
    size_pt = int(size.get(qn('w:val'))) / 2 if size is not None else None
    bold_el = rPr.find(qn('w:b'))
    bold = None
    if bold_el is not None:
        val = bold_el.get(qn('w:val'))
        bold = val not in ('false', '0')
    return east, size_pt, bold


def line_spacing_info(p):
    """返回 (rule, pt)：rule 为 EXACTLY/AT_LEAST/MULTIPLE 或 None。"""
    pPr = p._p.find(qn('w:pPr'))
    if pPr is None:
        return None, None
    spacing = pPr.find(qn('w:spacing'))
    if spacing is None:
        return None, None
    rule, line = spacing.get(qn('w:lineRule')), spacing.get(qn('w:line'))
    if line is None:
        return None, None
    v = int(line)
    if rule == 'exact':
        return 'EXACTLY', v / 20
    if rule == 'atLeast':
        return 'AT_LEAST', v / 20
    return 'MULTIPLE', v / 240


def body_order(doc):
    """返回 body 中段落/表格的先后序列，用于核对"标题在表格上方"。"""
    seq = []
    for child in doc.element.body:
        if child.tag == qn('w:p'):
            seq.append(('p', child))
        elif child.tag == qn('w:tbl'):
            seq.append(('tbl', child))
    return seq


def text_of_p(el):
    return "".join(node.text or "" for node in el.iter(qn('w:t')))


def role_of(text, runs, index):
    """与 extract_template.py 保持一致的元素角色判定。"""
    t = text.strip()
    if RE_DOC_TITLE.match(t):
        return "doc-title"
    if RE_H1.match(t):
        return "h1"
    if RE_H2.match(t):
        return "h2"
    if RE_CAPTION_NUM.match(t):
        return "caption"
    if RE_CAPTION_SUFFIX.match(t):
        return "caption"
    if index < 30 and RE_LABEL.match(t) and len(t) < 60:
        return "header-label"
    if RE_H3.match(t):
        return "h3"
    if RE_COVER.search(t):
        return "cover-title"
    return "body"


def load_baseline(path: Path):
    """读取版式规范 JSON，返回 {role: expect} 与原始数据。"""
    data = json.loads(path.read_text(encoding="utf-8"))
    expect = {}
    for role, r in (data.get("roles") or {}).items():
        ls = r.get("line_spacing") or {}
        expect[role] = {
            "font_east_asia": r.get("font_east_asia"),
            "font_family": font_family(r.get("font_east_asia")),
            "size_pt": r.get("size_pt"),
            "bold": r.get("bold"),
            "first_line_chars": r.get("first_line_chars") or 0,
            "line_spacing": {"rule": ls.get("rule"), "pt": ls.get("pt")},
            "confidence": r.get("font_confidence"),
        }
    return data, expect


def validate(path: Path, profile: str, baseline_path: Path | None = None):
    doc = Document(str(path))
    failures = []
    checked = 0
    baseline_info = None

    if baseline_path is not None:
        if not baseline_path.is_file():
            print(f"[错误] 版式基线不存在：{baseline_path}", file=sys.stderr)
            raise SystemExit(2)
        baseline_info, expect = load_baseline(baseline_path)
    else:
        expect = DEFAULT_EXPECT_COURSE_STANDARD if profile == "course-standard" else {}

    use_expect = bool(expect)
    header_font_want = (expect.get("header-label", {}) or {}).get("font_east_asia") or "仿宋"

    def fail(where, expected, actual):
        failures.append({"where": where, "expected": expected, "actual": actual})

    for idx, p in enumerate(doc.paragraphs):
        text = p.text.strip()
        if not text:
            continue
        runs = [r for r in p.runs if r.text.strip()]
        if not runs:
            continue
        where = f"段落[{idx}] {text[:18]}"

        east, size_pt, _bold = run_font(runs[0])
        checked += 1
        if east is None:
            fail(where, "eastAsia 中文字体已设置", "未设置（Word 中中文会回退默认字体）")
            continue
        if east not in ALLOWED_FONTS:
            fail(where, f"字体族属于 {sorted(ALLOWED_FONTS)}", east)

        if HINT_RE.search(text):
            fail(where, "模板括号提示文字应已删除", text[:40])

        flc, _fli = para_indent(p)
        role = role_of(text, runs, idx)
        exp = expect.get(role)

        if use_expect and exp:
            want_font = exp.get("font_east_asia")
            want_family = exp.get("font_family") or font_family(want_font)
            if want_font and want_family and font_family(east) != want_family:
                fail(where, f"{role} 字体 {want_font}", east)
            want_size = exp.get("size_pt")
            if want_size is not None and size_pt is not None and abs(size_pt - want_size) > 0.01:
                fail(where, f"{role} 字号 {want_size}pt", f"{size_pt}pt")
            want_flc = int(exp.get("first_line_chars") or 0)
            got_flc = int(flc) if flc not in (None, '') else 0
            if got_flc != want_flc:
                fail(where,
                     f"{role} 首行缩进 {want_flc / 100:g} 字符"
                     + ("（顶格）" if want_flc == 0 else ""),
                     f"{got_flc / 100:g} 字符")
            ls_exp = exp.get("line_spacing") or {}
            if ls_exp.get("rule") and ls_exp.get("pt") is not None:
                rule, pt = line_spacing_info(p)
                if rule is not None and abs((pt or 0) - ls_exp["pt"]) > 0.01:
                    fail(where, f"{role} 行距 {ls_exp['rule']} {ls_exp['pt']} 磅",
                         f"{rule} {pt} 磅")

        if role == "header-label":
            for run in runs:
                e, _s, b = run_font(run)
                if run.text.strip().endswith(("：", ":")):
                    if b is not True:
                        fail(f"{where} · 标签 run {run.text[:10]!r}",
                             "头部标签加黑 bold=True", f"bold={b} font={e}")
                    if e and font_family(e) != font_family(header_font_want):
                        fail(f"{where} · 标签 run {run.text[:10]!r}",
                             f"头部标签字体 {header_font_want}", e)
                else:
                    if b is True:
                        fail(f"{where} · 值 run {run.text[:10]!r}",
                             "头部值不加黑 bold=False", "bold=True")
                    if e and font_family(e) != font_family(header_font_want):
                        fail(f"{where} · 值 run {run.text[:10]!r}",
                             f"头部值字体 {header_font_want}", e)

    seq = body_order(doc)
    table_positions = [i for i, (kind, _el) in enumerate(seq) if kind == 'tbl']
    for order, pos in enumerate(table_positions):
        table = doc.tables[order]
        caption = None
        for back in range(pos - 1, max(pos - 4, -1), -1):
            kind, el = seq[back]
            if kind == 'p' and text_of_p(el).strip():
                caption = text_of_p(el).strip()
                break
        head = table.rows[0].cells[0].text.strip()
        if caption is None:
            fail(f"表格[{order}] 首行 {head[:12]!r}", "表格上方应有标题段", "未找到标题段")
        elif "表" not in caption and "课程标准" not in caption:
            fail(f"表格[{order}]", "表格上方标题段以'表N'开头", caption[:30])

    for ti, table in enumerate(doc.tables):
        for ri, row in enumerate(table.rows):
            for ci, cell in enumerate(row.cells):
                for p in cell.paragraphs:
                    t = p.text.strip()
                    if not t:
                        continue
                    if HINT_RE.search(t):
                        fail(f"表格[{ti}] r{ri}c{ci}", "模板括号提示文字应已删除", t[:40])
                    runs = [r for r in p.runs if r.text.strip()]
                    if runs:
                        e, _s, _b = run_font(runs[0])
                        if e is None:
                            fail(f"表格[{ti}] r{ri}c{ci}", "eastAsia 中文字体已设置", "未设置")
                        elif e not in ALLOWED_FONTS:
                            fail(f"表格[{ti}] r{ri}c{ci}", "字体族合规", e)

    return {
        "file": str(path),
        "profile": profile,
        "baseline": str(baseline_path) if baseline_path is not None else None,
        "baseline_source": (baseline_info or {}).get("source", {}).get("kind") if baseline_info else None,
        "expectation_source": ("baseline" if baseline_path is not None
                               else ("builtin-default" if use_expect else "none")),
        "paragraphs_checked": checked,
        "tables": len(doc.tables),
        "passed": not failures,
        "failure_count": len(failures),
        "failures": failures[:60],
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="回读校验 docx 排版")
    ap.add_argument("docx", type=Path, help="待校验的 .docx")
    ap.add_argument("--profile", default="course-standard",
                    choices=["course-standard", "lesson", "schedule"])
    ap.add_argument("--baseline", type=Path, default=None,
                    help="版式规范 JSON（由 extract_template.py 产出）；缺省时按内置默认规范校验")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    if not args.docx.is_file():
        print(f"[错误] 文件不存在：{args.docx}", file=sys.stderr)
        return 2

    report = validate(args.docx, args.profile, args.baseline)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        src = report["expectation_source"]
        src_txt = {"baseline": f"用户模板版式基线（{report['baseline']}）",
                   "builtin-default": "内置默认规范（format-rules.md）",
                   "none": "未做字体字号校验（该 profile 无默认规范）"}[src]
        print("=" * 62)
        print(f" 排版回读校验 · {report['file']}")
        print(f" profile={report['profile']}  段落={report['paragraphs_checked']}  表格={report['tables']}")
        print(f" 期望值来源：{src_txt}")
        print("=" * 62)
        if report["passed"]:
            print("  结果：PASS —— 字体族 / 字号 / 首行缩进 / 行距 / 头部双层 run / 标题与表格顺序 均合规")
        else:
            print(f"  结果：FAIL —— 共 {report['failure_count']} 项")
            for item in report["failures"]:
                print(f"  [FAIL] {item['where']}")
                print(f"         期望：{item['expected']}")
                print(f"         实测：{item['actual']}")
        print("=" * 62)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
