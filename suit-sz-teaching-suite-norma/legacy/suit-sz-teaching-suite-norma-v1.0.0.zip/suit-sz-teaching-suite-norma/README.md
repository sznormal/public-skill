# 深信院教学文件写作套件（统一版）· suit-sz-teaching-suite-norma

深圳信息职业技术大学（深信院）教学公文一站式写作技能。一个技能闭环完成三类教学公文的撰写与自查：

1. **《课程标准》**（课程设计总纲，含课程思政融入表）
2. **教案 + 学期授课计划**（落地执行件，须以课标为输入）
3. **督导一致性检查**（核对版本 / 格式 / 内容 / 三份文件互相匹配）

> 本技能是 `course-standard-writer`、`teaching-docs-writer`、`teaching-docs-suite` 三者的**合并替代版**。部署后旧三者应停用删除，避免重复触发。

## 架构（AFP Pattern 5 · 薄路由 + 按需 Read）

```
suit-sz-teaching-suite-norma/
├─ SKILL.md                     # 薄路由主控：意图识别 → 分流到阶段
├─ stages/
│  ├─ 01-intent.md              # 意图识别与分流
│  ├─ 02-course-standard.md     # 写《课程标准》（含课程思政融入表）
│  ├─ 03-lesson-schedule.md     # 写教案+授课计划（教学过程挂钩标思政点）
│  └─ 04-supervisor.md          # 督导角色：版本/格式/内容/三文件一致性
├─ modules/
│  ├─ sziit-format.md           # 深信院排版规范（共享基线）
│  └─ politics-integration.md   # 思政点→教学过程 映射规则（核心新增）
├─ references/
│  ├─ teacher-checklist.md      # 老师需提供内容清单 A~I + 必问清单
│  └─ format-spec.md            # 字体/字号/行距细则 + 模板解析方法
├─ scripts/
│  ├─ check_environment.py      # 依赖自检（python-docx/openpyxl/olefile/pymupdf）
│  ├─ docx_helpers.py           # 字体/缩进/单元格/标题表格插入 公共函数
│  ├─ doc_extract.py            # 旧 .doc（OLE2）文本提取
│  ├─ progress_dashboard.py     # ASCII 进度仪表盘
│  ├─ inspect_full.py / inspect_header.py / test_helper.py
├─ templates/
│  ├─ 课程标准.docx             # 课标空白模板
│  ├─ 教案模板.docx             # 教案空白模板
│  └─ 课程计划-空白模板.docx    # 授课计划空白模板
└─ AFP-SPEC-CONFORMANCE.md      # AFP-SPEC 合规证书（Silver）
```

## 快速开始

| 你想做 | 说这句话 | 进入阶段 |
|---|---|---|
| 写课标 | "帮我写《XXX》课程标准" | P2 |
| 写教案+授课计划 | "据这份课标生成教案和授课计划" | P3（须先给课标） |
| 督导自查 | "检查一下这三份文件是否一致" | P4 |

## 关键设计点

- **链路顺序**：先课标 → 后教案/授课计划 → 最后督导。教案/授课计划必须**以写好的课标为输入**，严禁凭空编造。
- **思政贯穿**：教案"教学过程"必须回溯课标《课程思政融入表》的"知识点→思政融入点→思政案例"，并在独立「思政融入」栏目与教学过程落点中体现。
- **落盘思维**：每阶段实质产物（数据 JSON / 生成 docx / 督导报告）都写成具名文件，可复用、可交接、可复现。
- **督导闭环**：交付前由 P4 核对版本/格式/内容/三文件一致性，输出检查报告。

## 依赖

- 必需：python-docx、openpyxl、olefile（渲染/解析）
- 可选：pymupdf（PDF 逐页校验；缺失则跳过，核心流程不受影响）
- 写文档前必跑 `scripts/check_environment.py`；缺必需包按提示 `python -m pip install ...`（用受管 Python venv，勿全局安装）。

## 适用边界

- 仅适用于**深圳信息职业技术大学**公文系模板；其他学校版式须先经使用者确认。
- 不处理单页讲义、PPT、报告、论文、公函等非公文系教学文档。

---
*版本：1.0.0 · 2026-08-30 · 维护者：norma（中德机器人学院 / 深圳信息职业技术大学）*
