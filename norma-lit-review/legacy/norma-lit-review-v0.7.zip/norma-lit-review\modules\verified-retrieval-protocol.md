# 验证检索协议（Verified Retrieval & Verification Protocol）

> Norma理工科文献综述 · Module
> 被 P2（多库检索）、P6（参考文献核验）引用。
> 来源：deep-research skill 的 lit-review 模式 + 本环境**实测验证**的真实运行经验
>      （2026-08-18 在 managed Python 3.13 + 沙箱中跑通 arXiv/Semantic Scholar 客户端）。
> 核心思想：**检索与核验必须"真实可复现"，占位编号 / 编造标题 / 臆测被引一律零容忍。**

---

## 一、两层检索范式（优先级）

| 层级 | 方式 | 何时用 | 真实性保障 |
|------|------|--------|-----------|
| **L1 API 客户端**（优先） | 直接调 arXiv API / Semantic Scholar API（见 P6 客户端段） | 环境可联网、且有脚本运行能力 | 返回数据库原始字段，最可信 |
| **L2 WebSearch 兜底** | 用 WebSearch / WebFetch 找题录 + 逐条核 DOI/编号 | L1 不可用（无脚本能力 / 网络受限） | 必须**逐条**核对 DOI/arXiv ID 并透明披露"经联网核对" |

> 无论哪层，最终每条文献都必须带一个 `verifiable_id`（arXiv ID > DOI > 知网题名+一作）。
> **没有可核验标识的文献，宁可少收，绝不写入疑似编造条目。**

---

## 二、英文核验引擎（实测可用）

### 2.1 arXiv API（免费、无需认证）
```
GET http://export.arxiv.org/api/query?id_list=2308.08155&max_results=1
```
- 返回 Atom XML，含 `<title>` / `<author>` / `<published>`。
- **题目交叉校验**：用 `arxiv_client.py` 的 `ArxivClient.arxiv_id_lookup(id, title)`，
  对返回的规范标题做 **0.70 相似度**比对——**能抓出"ID 有效但清单标题漂移"**的隐藏错误。

### 2.2 Semantic Scholar API（DOI 优先 + 标题兜底）
```
GET https://api.semanticscholar.org/graph/v1/paper/DOI:{doi}?fields=title,authors,year,externalIds,venue
GET https://api.semanticscholar.org/graph/v1/paper/search?query={title}&limit=5&fields=...
```
- **先 DOI 后标题**：DOI 命中即交叉核对标题（相似度 ≥ 0.70 才认 matched）。
- 内置 **429 退避**（背压 sleep + 刷新锚点），符合未认证 1 req/s 节流。

### 2.3 S2_API_KEY（强烈建议配置，解除限流）
- 客户端读取环境变量 **`S2_API_KEY`**（或命令行 `--api-key`）。
- 有 key：限速从 **1 req/s → 10 req/s**（min_interval 0.1s），否则未认证层易持续触发 429。
- 获取：https://www.semanticscholar.org/product/api → API Keys（免费 tier）。
- ⚠️ **安全（重要）**：**本 skill 不内置任何密钥，也不会替你保存 key。**
  - 不要把 key 写进会被云盘/版本库同步的目录（如百度网盘、GitHub 仓库）。
  - 推荐：用环境变量临时传入，或在本地**不入库、不同步**的文件里保存，由驱动脚本读取。
  - 用法（一次性内联，避免落盘）：
  ```bash
  S2_API_KEY="你的key" python verify_references.py
  ```

### 2.4 环境实测结论
- 任意 Python 3.8+（含 WorkBuddy 自带的 managed Python）仅用 **stdlib（urllib / xml）即可跑**，
  无需建 venv、无需 pip。
- 脚本自带节流与 429 退避；arXiv(http) / S2(https) 均可正常访问。

---

## 三、中文核验（关键边界）

- **原装中文客户端不爬知网/万方**：受 ToS 与法律风险约束，CNKI/Wanfang 检索页与全文页
  **绝不抓取**（Zero-scraping）。因此中文题录无法用开放 API 自动"标题级"核验，
  只能核验到 DOI 存在性（doi.org RA 分诊 + Handle 存在）。
- **务实兜底（本环境验证有效）**：用 **WebSearch 直接搜"题名 + 第一作者 + 期刊"**，
  命中知网/万方页后**核对 DOI 与卷期页**，比调原装中文客户端更可靠——
  因为 WebSearch 能看到期刊页题录，而客户端只到"DOI 存在"为止。
- **三态语义**：`matched / unmatched / skipped`——一个 miss **永不**被判为"伪造"
  （precision over recall）；查不到只进人工确认清单，不自动删。

---

## 四、标题漂移（ID_MISMATCH）处理

实测案例（2026-08-18）：清单标题与 API 规范标题不符，但论文**真实存在**——
- E3 清单"Collaborative LLMs…" → 规范"*LLMs Working in Harmony: A Survey on the Technological Aspects of Building Effective LLM-Based Multi Agent Systems*"
- E13 清单"Surfer 2: Free Multilingual Reasoning LLM" → 规范"*Surfer 2: The Next Generation of Cross-Platform Computer Use Agents*"
- E14 清单"CoELA: Collaborative Embodied Language Agents" → 规范"*Building Cooperative Embodied Agents Modularly with Large Language Models*"

→ **以 API 规范标题为准修正清单**，并记一行勘误。这正是纯 WebSearch 检索易漏的盲区，
   API 级交叉校验的价值所在。

---

## 五、IRON RULE（反幻觉硬律）

1. 每条论断必须有引文。
2. 每个引用必须**独立核验**（L1/L2 任一）。
3. **"难以验证"= 不合格**：灰区即 FAIL，不能标"不确定"了事。
4. 占位编号（`arXiv:xxxx.x` / `24xx.x`）一律拒绝；推断标题 / 编造作者一律拒绝。
5. 无法确认真实存在的文献 → 默认删除，不保留在可提交稿中。

---

## 六、配套脚本

- `scripts/verify_references.py`（仅 stdlib，自包含）：读参考文献 JSON，
  对 arXiv ID / DOI 调 API 核验，0.70 标题相似度交叉校验，429 退避，
  支持 `S2_API_KEY` 环境变量；输出核验报告。详见该脚本头部说明。
- 若已安装 `academic-research-skills`，也可复用其 `scripts/arxiv_client.py`
  与 `scripts/semantic_scholar_client.py`（接口一致，本模块协议与其兼容）。
