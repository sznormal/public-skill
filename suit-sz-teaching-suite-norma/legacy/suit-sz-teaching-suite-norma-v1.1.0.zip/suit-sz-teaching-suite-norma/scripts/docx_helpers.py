# -*- coding: utf-8 -*-
"""python-docx 公共工具：教学文档（教案/授课计划）渲染用。
用法：将本文件与本目录同置，from docx_helpers import ...
"""
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


def set_run_font(run, name, size=None, bold=None, underline=None):
    """设置 run 字体。中文必须写 eastAsia，否则 Word 中中文不生效。"""
    run.font.name = name
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.get_or_add_rFonts()
    rFonts.set(qn('w:eastAsia'), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if underline is not None:
        run.font.underline = underline


def set_first_line_chars(p, chars=2, size_pt=14):
    """首行缩进 chars 个字符（随字号自适应）。"""
    pPr = p._p.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        ind = OxmlElement('w:ind')
        pPr.append(ind)
    ind.set(qn('w:firstLineChars'), str(chars * 100))
    ind.set(qn('w:firstLine'), str(int(chars * 100 * size_pt / 10)))


def reset_para(p, text, name=None, size=None, underline=False, align=None):
    """清空段落所有 run，写入单 run 文本（可选格式）。"""
    for r in list(p.runs):
        r._element.getparent().remove(r._element)
    if align is not None:
        p.alignment = align
    r = p.add_run(text)
    set_run_font(r, name, size=size, underline=underline)
    return r


def clear_cell(cell, line1=True):
    """清空单元格：删多余段落、清首段 run，返回可写首段。"""
    ps = list(cell.paragraphs)
    for p in ps[1:]:
        p._element.getparent().remove(p._element)
    p = ps[0]
    for r in list(p.runs):
        r._element.getparent().remove(r._element)
    if line1:
        p.paragraph_format.line_spacing = 1.0
    return p


def new_para(cell, text, name='仿宋_GB2312', size=14, bold=None,
             align=None, indent=True, line1=True):
    """在单元格追加填写值段落：默认仿宋四号、首行缩进2字符、单倍行距。"""
    p = cell.add_paragraph()
    if align is not None:
        p.alignment = align
    if line1:
        p.paragraph_format.line_spacing = 1.0
    if indent:
        set_first_line_chars(p, 2, size_pt=size)
    r = p.add_run(text)
    set_run_font(r, name, size=size, bold=bold)
    return p


def value_cell(row):
    """合并单元格场景：row.cells 重复返回合并格，按去重文本取'标签格之后'的值格。"""
    seen = []
    for c in row.cells:
        t = c.text.strip()
        if t not in [x[0] for x in seen]:
            seen.append((t, c))
    return seen[1][1] if len(seen) >= 2 else seen[0][1]


def fill_lines(row, lines, name='楷体_GB2312', size=12):
    """表格0式多行填写：清值格后逐行写入。"""
    cell = value_cell(row)
    first = clear_cell(cell)
    for i, line in enumerate(lines):
        if i == 0:
            r = first.add_run(line)
            set_run_font(r, name, size=size)
        else:
            new_para(cell, line, name=name, size=size, indent=False)


def fill_center(cell, text, name='仿宋_GB2312', size=10):
    """周次表式短值填写：居中、无缩进。"""
    p = clear_cell(cell)
    r = p.add_run(text)
    set_run_font(r, name, size=size)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER


def fill_left(cell, text, name='仿宋_GB2312', size=10):
    """周次表式长文本填写：左对齐、无缩进。"""
    p = clear_cell(cell)
    r = p.add_run(text)
    set_run_font(r, name, size=size)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT


def fill_cover_label(doc, label, value):
    """封面'标签：值'段落：保留标签 run 与下划线格式，改写值 run。"""
    for p in doc.paragraphs:
        if p.text.strip().startswith(label):
            if len(p.runs) >= 2:
                p.runs[1].text = '  ' + value
                for r in list(p.runs[2:]):
                    r._element.getparent().remove(r._element)
            return True
    return False


def dump_tables(doc, max_text=120):
    """打印全部表格结构（去重合并格），用于动手前定位行/列。"""
    for ti, tb in enumerate(doc.tables):
        print('== TABLE', ti, 'rows=', len(tb.rows), 'cols=', len(tb.columns))
        for ri, row in enumerate(tb.rows):
            uniq = []
            for c in row.cells:
                t = c.text.strip().replace('\n', '/')
                if not uniq or uniq[-1] != t:
                    uniq.append(t)
            print(ri, '|', ' || '.join(uniq)[:max_text])
