from docx import Document
from docx.oxml.ns import qn
import sys

if len(sys.argv) < 2:
    print("用法: python assets/inspect_full.py <模板docx路径>")
    sys.exit(1)
TEMPLATE = sys.argv[1]


def first_run_font(p):
    for r in p.runs:
        if not r.text.strip():
            continue
        rf = r._element.find(qn('w:rPr'))
        ea = None
        bold = None
        sz = None
        if rf is not None:
            rfonts = rf.find(qn('w:rFonts'))
            if rfonts is not None:
                ea = rfonts.get(qn('w:eastAsia'))
            b = rf.find(qn('w:b'))
            bold = b.get(qn('w:val')) if b is not None else '0'
            s = rf.find(qn('w:sz'))
            sz = s.get(qn('w:val')) if s is not None else None
        return ea, bold, sz
    return None, None, None


d = Document(TEMPLATE)
print("=== TEMPLATE 各结构层级字体(首个非空run) ===")
interesting = ('《', '一、', '二、', '三、', '四、', '五、', '六、', '七、', '八、',
               '（一）', '（二）', '（三）', '1.软硬件', '2.师资', '1.考核', '2.总评',
               '教材使用', '模块一', '模块二', '学时分配表', '实践教学安排表')
for p in d.paragraphs:
    t = p.text.strip()
    if not t:
        continue
    for key in interesting:
        if t.startswith(key):
            ea, bold, sz = first_run_font(p)
            print("  [%s] ea=%s bold=%s sz=%s | sample=%s" % (key, ea, bold, sz, t[:20]))
            break

# header lines full run dump
print("")
print("=== TEMPLATE 头部信息栏 全run详情 ===")
started = False
for p in d.paragraphs:
    t = p.text.strip()
    if t.startswith(('课程类别', '适用专业', '学分', '编写执笔人', '审定负责人')):
        started = True
        parts = []
        for r in p.runs:
            if not r.text.strip():
                continue
            rf = r._element.find(qn('w:rPr'))
            ea = None; bold = None
            if rf is not None:
                rfonts = rf.find(qn('w:rFonts'))
                if rfonts is not None:
                    ea = rfonts.get(qn('w:eastAsia'))
                b = rf.find(qn('w:b'))
                bold = b.get(qn('w:val')) if b is not None else '0'
            parts.append("'%s'[ea=%s,b=%s]" % (r.text[:14], ea, bold))
        print("  " + " | ".join(parts))
    elif started and t.startswith(('一、', '《')):
        break
