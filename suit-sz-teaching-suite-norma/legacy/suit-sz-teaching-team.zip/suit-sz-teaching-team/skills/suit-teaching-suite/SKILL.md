---
name: suit-teaching-suite
description: 高校教学文件专家团共享工具箱——内置课标/教案/授课计划空白模板、模板版式提取、确定性渲染、回读校验、**已有教学文件审核**（教学必备项目/表格填写完整度/跨文件一致性）与降级产出脚本，以及排版规范与思政融入写法参考。由专家团成员按角色分头调用。
---

# 高校教学文件 · 共享工具箱

本目录是**高校教学文件专家团**（College Teaching Document Team）的共享资源库，由团长与四位成员按角色分头使用。

> 这里不是给用户直接召唤的入口。用户对话入口是专家团本身，团长负责决定谁读哪份文件、谁跑哪个脚本。

## 一、谁来用哪一部分

| 角色 | 主要用到 |
|---|---|
| `template-extractor` 版式规范提取师 | `scripts/extract_template.py`、`templates/`、`references/template-extraction.md` |
| `course-standard-writer` 课程标准主笔 | `scripts/render_course_standard.py`、`scripts/validate_docx.py`、`scripts/docx_helpers.py`、`references/format-rules.md`、`references/teacher-checklist.md`、`references/workflow-course-standard.md` |
| `lesson-plan-writer` 教案与授课计划主笔 | `scripts/docx_helpers.py`、`scripts/validate_docx.py`、`references/format-rules.md`、`references/politics-integration.md`、`references/workflow-lesson-schedule.md` |
| `doc-supervisor` 教学文件督导 | `scripts/audit_docs.py`、`scripts/validate_docx.py`、`scripts/check_environment.py`、`references/workflow-supervisor.md`、`references/teacher-checklist.md` |
| 全员 | `scripts/check_environment.py`（开工第一步） |

## 二、开工第一步：环境自检

```
<python> scripts/check_environment.py
```

**不要用裸 `python`**：沙箱与部分环境里 `python` 可能不在 PATH 上，或指向未装 python-docx 的解释器。第一次用一个能跑起来的解释器执行本脚本即可，它会在自己与受管 Python 目录里查找，并输出：

- 总体状态：`ready` / `partial` / `needs_setup` / `unavailable`
- `recommended_interpreter`：**后续所有脚本都用这个解释器执行**
- `runtime_level`：L1（可出 docx）或 L2（Markdown 降级）

加 `--json` 取机器可读结果。自检不安装、不登录、不授权、不改配置、不访问网络。

## 三、脚本清单

| 脚本 | 用途 | 关键参数 |
|---|---|---|
| `check_environment.py` | 只读环境自检，给四态结论与推荐解释器 | `--json` |
| `extract_template.py` | **模板版式提取**：读取 .docx 模板的真实字体/字号/缩进/行距/表格结构，产出机器可读版式基线与差异清单 | `<模板.docx>` `--doc-type` `--out` `--markdown` `--against-builtin` |
| `render_course_standard.py` | JSON → 排版合规的课标 docx | `--data` / `--out` / `--demo` / `--no-template` |
| `validate_docx.py` | 回读 docx 校验**排版**与结构，输出位置/期望/实测；期望值可用版式基线 | `<docx> --profile course-standard\|lesson\|schedule` `--baseline 版式规范.json` |
| `audit_docs.py` | **审核已有文件**（只读）：教学必备项目、表格填写完整度、跨文件一致性（学时勾稽 / 周次连续 / 思政覆盖 / 字段一致），产出 Markdown + JSON 报告；有 ❌ 时退出码 1 | `<docx...>` `--dir` `--out` `--json` `--demo-dir` |
| `selftest.py` | 端到端自测 10 项（含审核正反用例） | `--out` / `--json` |
| `export_markdown.py` | L2 降级产出 Markdown + 版式对照表 | `--data` / `--type` / `--out` / `--demo` |
| `docx_helpers.py` | 公共函数：字体、缩进、单元格、标题+表格插入 | 供上面脚本与临时脚本 import |
| `doc_extract.py` | 提取旧版 .doc（OLE2）文本 | `<doc 路径>` |
| `progress_dashboard.py` | 在确认门处显示"写到哪、卡在哪" | 供工作流调用 |

## 四、内置模板

`templates/` 下三份空白模板，为**用户未提供模板时的默认版式基线**：

- `课程标准.docx`
- `教案模板.docx`
- `课程计划-空白模板.docx`

默认版式取自深圳信息职业技术大学校版；其他院校请让用户提供本校模板，由 `template-extractor` 提取后以其实际值为准。

## 五、参考文件（按需读取）

| 文件 | 什么时候读 |
|---|---|
| `references/template-extraction.md` | 做模板提取、判读版式基线与差异时 |
| `references/format-rules.md` | **涉及任何排版时必读**：字体、字号、首行缩进、行距、标题与表格顺序、python-docx 函数清单 |
| `references/politics-integration.md` | 写教案"教学过程"或核对思政覆盖时 |
| `references/teacher-checklist.md` | 向老师收集素材，需要逐项清单时 |
| `references/workflow-course-standard.md` | 写课标 |
| `references/workflow-lesson-schedule.md` | 写教案与授课计划 |
| `references/workflow-supervisor.md` | 做督导审核（存量文件审核 / 撰写收尾） |
| `references/setup-guide.md` | 环境缺失、安装、卸载与回滚 |

## 六、降级策略（缺什么降什么，绝不整体停摆）

| 级别 | 触发条件 | 交付形态 |
|---|---|---|
| **L1 完整** | 找到可 import python-docx 的解释器 | 生成排版对齐模板的 `.docx`（首选） |
| **L2 Markdown** | 没有可用 python-docx | `scripts/export_markdown.py` 产出 `.md` 全文 + Word 版式对照表，用户粘贴进本校模板即可 |
| **L3 纯文本** | 连文件写入也受限 | 直接在对话中输出完整结构化内容 + 版式说明 |

- 缺 python-docx 且用户接受安装 → 按 `references/setup-guide.md` 引导，装完重跑自检。
- 缺 python-docx 且用户不愿安装 → 按 L2 继续干活，**不停工等安装**，并在交付时标注"未产出 docx"。
- 缺 python-docx 时**模板提取也会降级**：改用内置默认版式基线，并明确标注"未提取用户模板版式"。
- 缺 openpyxl / olefile → 只影响 xlsx 大纲与旧版 .doc 的自动解析，改为请用户给文本或转存 .docx。
- 逐项降级的限制、恢复与停止条件见 `skill-dependencies.json`。

## 七、四条不可绕过的铁律

1. **撰写链路：先课标 → 后教案/授课计划 → 最后督导。没有课标绝不写教案。**（此条只约束撰写；**审核已有文件是独立入口，不受此前置约束**）
2. **审核链路只读**：审用户已有文件时，不改文件、不补内容。发现 ❌ 写进报告，由对应主笔返工，**返工后必须复检**。
3. **生成新文件，绝不覆盖用户模板**（用户常开着 Word，覆盖会损坏会话）。
4. **回读校验判 PASS 才交付。** 不声称"应该没问题"；未核对项一律标"未验证"，"没查成"与"不合规"分开写。
