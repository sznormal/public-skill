# 模板版式提取参考

`scripts/extract_template.py` 的字段含义、判读方法与常见坑。供 `template-extractor`（版式规范提取师）使用。

## 一、为什么必须有这一步

用户说"按我们学校的模板来"时，**模板里的真实规范只有机器读得出来**。人的眼睛能看出字体和字号，但看不出：

- 首行缩进到底是 `w:firstLineChars="200"`（2 字符，随字号自适应）还是根本没设
- 行距是固定值 28 磅，还是 1.5 倍行距（视觉接近，Word 里是两回事）
- 一级标题是顶格还是缩进 2 字符

这几项恰恰是**返工率最高**的。所以版式基线一律由脚本提取，不靠目测。

## 二、命令

```
<python> scripts/extract_template.py "<模板.docx>" \
    --doc-type course-standard|lesson|schedule|auto \
    --out "版式规范-<院校或默认>.json" \
    --markdown "版式规范-<院校或默认>.md" \
    --against-builtin
```

- `<python>` 取 `scripts/check_environment.py` 输出的 `recommended_interpreter`
- `--against-builtin` 与 `templates/` 下对应内置模板逐项比对
- 默认**同时产出** JSON（给下游脚本/成员）与 Markdown（给人读）
- 只读源文件，绝不修改模板

## 三、输出字段含义

### `source`
| 字段 | 含义 |
|---|---|
| `file` | 模板绝对路径 |
| `kind` | `user-template`（用户提供）或 `builtin-default`（内置默认） |
| `doc_type` | `course-standard` / `lesson` / `schedule` |

### `page`
页面宽高与四边页边距（pt），用于核对模板页面设置是否被保留。

### `roles` —— 核心
按元素角色聚合出的**逐维度众数**格式。角色取值：

| 角色 | 对应元素 |
|---|---|
| `doc-title` | 标题《XXX》课程标准 |
| `h1` | 一级标题（一、二、…八、） |
| `h2` | 二级标题（（一）（二）） |
| `h3` | 编号子标题（1. 2.） |
| `body` | 正文段落 |
| `caption` | 表格标题（学时分配表等） |
| `header-label` | 头部信息栏标签行 |
| `cover-title` | 教案/授课计划封面标题 |

每个角色含：`font_east_asia`、`size_pt`、`bold`、`align`、`first_line_chars`、`first_line_indent_pt`、`line_spacing{rule,pt}`、`space_before_pt`、`space_after_pt`、`sample_count`、`text_sample`，以及各维度的 `*_confidence`（众数占比）。

**为什么用逐维度众数而不是整条记录取众数**：同一角色下常有格式略有差异的段落。若整条记录计数，个别离群段（例如混进正文角色的表标题）会污染整类格式，导致 `body` 被读成"居中 + 顶格"。逐维度众数能把离群值稀释掉。

`*_confidence` 偏低（< 0.6）说明该类段落格式不统一，**要在报告里点名提示**，让下游知道该角色需要人工确认。

### `tables`
每个表格含 `rows`、`cols`、`grid`（合并还原后的文本网格）、`cells`（含 `is_label`、`row_has_merged_cells`、字体字号）。

### `labels`
固定标签清单（如 `课程名称：`、`学分：`），供下游按标签定位写入点。

### `cleanup_notes`
模板里残留的提示文字，生成前必须删除，例如：
- `（正文三号仿宋）`
- `（字体三号黑体）`
- `（需包括但不限于以下内容：）`
- `（线上教学平台的开发和课程资源的建设，……）`

### `diff_vs_builtin`
与内置默认基线的逐项差异，每条含 `item`（角色·维度）、`user`、`builtin`、`impact`。

## 四、差异影响判读

| impact | 覆盖维度 | 处理 |
|---|---|---|
| `high` | `font_east_asia`、`size_pt`、`first_line_chars`、`line_spacing` | **必须按用户模板执行**。不遵守必然排版返工 |
| `low` | `bold`、`align` | 可参考，按模板观感判断 |

判读要点：

- **字体族差异最要命**：黑体/楷体/仿宋这三级层级关系是校版规范的核心，换了字体族等于层级全乱。
- **首行缩进差异要逐角色看**：一级标题顶格、其余 2 字符。若模板里 `h1.first_line_chars` 是 `200`，说明该校一级标题也缩进，**照做**。
- **字号差异注意单位**：全部为 pt。"三号" = 16pt，"小四" = 12pt。
- 差异项为 0 说明用户模板与内置默认版式一致，可以放心用内置基线。

## 五、常见坑

1. **中文字体只认 `w:rFonts/@w:eastAsia`**。`run.font.name` 只反映西文字体，用它读中文字体会得到 `None`，下游全盘错。
2. **首行缩进优先读 `w:firstLineChars`**（百分之一字符，`200` = 2 字符），缺失时回退 `w:firstLine`（twips）折算。用固定 twips 写缩进会导致不同字号下缩进不一致。
3. **合并单元格必须按底层 `w:tc` 身份去重**：`row.cells` 在合并时会把同一个格重复返回多次，不去重会算出错误的列数。
4. **行距读 `w:spacing/@w:line` + `@w:lineRule`**，不要依赖 python-docx 的自动换算——`exact`（固定值）与 `auto`（多倍）在 API 层都可能表现为 Length，容易混淆。本脚本输出的 `line_spacing.rule` 为 `EXACTLY` / `AT_LEAST` / `MULTIPLE`。
5. **旧版 `.doc`（OLE2）不许猜格式**：脚本会直接报错退出（exit code 4）。此时应让用户另存为 `.docx`，或仅用 `scripts/doc_extract.py` 取正文文本，并把格式标注为"未提取"。
6. **模板里的排版说明文字不是正文**：`（字体三号黑体）` 这类注释要列进 `cleanup_notes`，渲染时删除，否则会印进正式文档。

## 六、没有用户模板时

同样要跑本脚本，只是把目标指向内置模板：

```
<python> scripts/extract_template.py "templates/课程标准.docx" --doc-type course-standard --out "版式规范-默认.json"
```

这样**下游永远拿到同一份格式的基线文件**，撰写专家不必判断"这次版式从哪来"。同时应向用户说明：

> 当前使用内置默认版式（深信院校版）。如需匹配贵校模板，请提供模板文件（.docx），我会提取其真实字体、字号、缩进与行距后重新生成。

## 七、回传要求

回传主理人时必须给**具体数据**（角色格式表 + 差异清单 + 待清理清单 + 未验证项），不能只说"提取完成"。
