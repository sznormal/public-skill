# 排版规范与模板解析方法

## 一、动手前先从模板提取实际规范（不要假设）

```python
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn

doc = Document(TEMPLATE)

# 1. 段落格式
for i, p in enumerate(doc.paragraphs):
    if p.text.strip():
        runs = [(r.text, r.font.name, r.font.size.pt if r.font.size else None,
                 r.font.bold, r.font.underline) for r in p.runs]
        print(i, repr(p.text[:30]), p.alignment, runs)

# 2. 表格结构（去重合并单元格）
for ti, tb in enumerate(doc.tables):
    print('TABLE', ti, len(tb.rows), 'x', len(tb.columns))
    for ri, row in enumerate(tb.rows):
        uniq = []
        for c in row.cells:
            t = c.text.strip().replace('\n', '/')
            if not uniq or uniq[-1] != t:
                uniq.append(t)
        print(ri, '|', ' || '.join(uniq)[:120])

# 3. 中文字体在 w:rFonts 的 eastAsia；run.font.name 只改西文
rPr = run._element.get_or_add_rPr()
rFonts = rPr.get_or_add_rFonts()
print(rFonts.get(qn('w:eastAsia')))
```

## 二、公文系教学模板通用规范（深信院）

### 字号对照
| 字号名 | pt |
|--------|-----|
| 小二 | 18 |
| 三号/小三 | 16 / 15 |
| 四号 | 14 |
| 小四 | 12 |
| 五号 | 10.5 |

### 中文字体族
- 方正公文小标宋：封面主标题
- 华文中宋：封面副标题
- 楷体_GB2312：封面填写值（带下划线）、授课计划表格0、签名日期行
- 仿宋_GB2312：教案表格填写值（四号）、授课计划周次表（10pt）、课标正文
- 黑体：课标一级/标题、教案表头标签（14pt）

### 段落格式
- 表格填写值：首行缩进 2 字符（`w:firstLineChars=200`），单倍行距
- 封面填写值：居中、下划线
- 时数/日期/课型等短值：居中、不缩进

### 编号体例
- 教学目标段：`#1、素质目标` / `（1）（2）（3）`
- 重点/难点：`1、2、3、`
- 教学过程：`第X学时（40分钟）：` → `一、二、三`（含分钟数）→ `1. 2. 3.`
- 周次表内容提要：`讲解：1.…；2.…。` + 换行 `实验：…`

## 三、python-docx 常用操作（封装在 scripts/docx_helpers.py）

| 函数 | 用途 |
|---|---|
| `set_run_font(run, name, size, bold, underline)` | 设中文字体（eastAsia）+ 字号 + 字重 |
| `set_first_line_chars(p, chars=2, size_pt=14)` | 首行缩进 N 字符（随字号自适应） |
| `clear_cell(cell)` | 清空单元格，返回可写首段 |
| `value_cell(row)` | 合并单元格按去重文本取"标签后的值格" |
| `insert_heading_table_before(doc, anchor_p, title, kind, make_table)` | "标题+表格"块：先标题后表格，顺序铁律 |

## 四、PDF 渲染验证（规避沙箱）

```powershell
& "<soffice路径>" -env:UserInstallation="file:///<可写目录>/lo_profile" `
    --headless --convert-to pdf --outdir "<输出目录>" "<docx>"
```
```python
import pymupdf
doc = pymupdf.open(pdf_path)
for i in range(doc.page_count):
    doc[i].get_pixmap(dpi=100).save(f'page_{i+1}.png')
```
逐页查看：字体是否生效（楷体/仿宋）、下划线、缩进、表格列宽与内容截断、跨页断行。
