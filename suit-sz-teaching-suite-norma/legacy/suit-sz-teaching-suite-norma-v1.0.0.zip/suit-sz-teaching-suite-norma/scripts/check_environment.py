#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
环境自检：检查本技能渲染所需依赖。

用法：
    python scripts/check_environment.py

返回：逐包打印 [OK] / [MISSING]，并以退出码 0/1 给出整体结论。
规则：
- 必需包缺失 → 明确提示安装命令，切勿静默降级或臆造排版。
- 可选包（pymupdf）缺失 → 核心流程继续，仅跳过 PDF 逐页校验。
"""
import importlib

# (import 名, 展示名, 是否必需)
REQUIRED = [
    ("docx", "python-docx", True),
    ("openpyxl", "openpyxl", True),
    ("olefile", "olefile", True),
]
OPTIONAL = [
    ("fitz", "pymupdf", False),
]

PIP_MAP = {
    "docx": "python-docx",
    "openpyxl": "openpyxl",
    "olefile": "olefile",
    "fitz": "pymupdf",
}


def check_one(mod: str):
    try:
        importlib.import_module(mod)
        return True
    except Exception:
        return False


def main():
    print("=" * 56)
    print(" suit-sz-teaching-suite-norma · 环境自检")
    print("=" * 56)
    all_ok = True
    missing_required = []
    for mod, name, _ in REQUIRED:
        ok = check_one(mod)
        print(f"  [{'OK' if ok else 'MISSING'}] {name} (import: {mod})")
        if not ok:
            all_ok = False
            missing_required.append(PIP_MAP.get(mod, mod))
    for mod, name, _ in OPTIONAL:
        ok = check_one(mod)
        print(f"  [{'OK' if ok else '  SKIP '}] {name} (import: {mod}) (可选)")
        if not ok:
            print(f"        ↳ 可选包缺失：PDF 逐页校验将跳过（核心流程不受影响）")
    print("-" * 56)
    if missing_required:
        print("缺少必需依赖，请先安装：")
        print(f"    python -m pip install {' '.join(missing_required)}")
        print("（使用 WorkBuddy 受管 Python 的 venv，勿全局安装）")
        raise SystemExit(1)
    print("环境就绪：必需依赖全部满足 ✅")
    raise SystemExit(0)


if __name__ == "__main__":
    main()
